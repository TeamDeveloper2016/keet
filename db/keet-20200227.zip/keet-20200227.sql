/*
SQLyog Community v12.2.4 (64 bit)
MySQL - 10.1.16-MariaDB : Database - keet
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`keet` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_bin */;

USE `keet`;

/*Table structure for table `tc_janal_ayudas` */

DROP TABLE IF EXISTS `tc_janal_ayudas`;

CREATE TABLE `tc_janal_ayudas` (
  `id_ayuda` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(750) COLLATE latin1_bin NOT NULL,
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ayuda`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_booleanos` */

DROP TABLE IF EXISTS `tc_janal_booleanos`;

CREATE TABLE `tc_janal_booleanos` (
  `id_booleano` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_booleano`),
  UNIQUE KEY `descripcion` (`descripcion`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_janal_booleanos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_campos` */

DROP TABLE IF EXISTS `tc_janal_campos`;

CREATE TABLE `tc_janal_campos` (
  `id_campo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_catalogo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin NOT NULL,
  `tipo` varchar(1) COLLATE latin1_bin NOT NULL,
  `mascara` varchar(255) COLLATE latin1_bin NOT NULL,
  `mostrar` int(1) NOT NULL,
  `capturar` int(1) NOT NULL,
  `longitud` bigint(10) NOT NULL,
  `orden` int(3) NOT NULL,
  `duplicados` varchar(1) COLLATE latin1_bin NOT NULL,
  `ver_mas` int(1) NOT NULL,
  `foraneo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `buscar` int(1) NOT NULL,
  `validacion` varchar(255) COLLATE latin1_bin NOT NULL,
  `error` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `modificar` int(1) NOT NULL,
  `formato` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `seleccionar` int(1) NOT NULL,
  `dependencia` int(3) DEFAULT NULL,
  `encriptado` int(1) NOT NULL,
  PRIMARY KEY (`id_campo`),
  KEY `id_catalogo` (`id_catalogo`),
  CONSTRAINT `tc_janal_campos_ibfk_1` FOREIGN KEY (`id_catalogo`) REFERENCES `tc_janal_catalogos` (`id_catalogo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_catalogos` */

DROP TABLE IF EXISTS `tc_janal_catalogos`;

CREATE TABLE `tc_janal_catalogos` (
  `id_catalogo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin NOT NULL,
  `tipo_tabla` int(1) NOT NULL,
  `precondicion` varchar(300) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_catalogo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_cfg_claves` */

DROP TABLE IF EXISTS `tc_janal_cfg_claves`;

CREATE TABLE `tc_janal_cfg_claves` (
  `id_cfg_clave` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) COLLATE latin1_bin NOT NULL,
  `vigencia_inicio` timestamp NULL DEFAULT NULL,
  `vigencia_fin` timestamp NULL DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cfg_clave`),
  UNIQUE KEY `primary_24` (`descripcion`),
  KEY `tc_janal_cfg_claves_ibfk_1` (`id_usuario`),
  CONSTRAINT `tc_janal_cfg_claves_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_cfg_detalles_claves` */

DROP TABLE IF EXISTS `tc_janal_cfg_detalles_claves`;

CREATE TABLE `tc_janal_cfg_detalles_claves` (
  `id_cfg_detalle_clave` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cfg_clave` bigint(11) unsigned NOT NULL,
  `nivel` bigint(10) NOT NULL,
  `longitud` bigint(10) NOT NULL,
  `dominio` bigint(10) NOT NULL,
  `id_tipo_justificacion` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cfg_detalle_clave`),
  UNIQUE KEY `primary_70` (`id_cfg_detalle_clave`),
  KEY `fk_tc_janal_cfg_detalles_clave` (`id_cfg_clave`),
  KEY `fk_tc_janal_cfg_detalles_cla_1` (`id_tipo_justificacion`),
  KEY `tcikusu_tcikcfdeta_fk` (`id_usuario`),
  CONSTRAINT `tc_janal_cfg_detalles_claves_ibfk_1` FOREIGN KEY (`id_cfg_clave`) REFERENCES `tc_janal_cfg_claves` (`id_cfg_clave`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_cfg_detalles_claves_ibfk_2` FOREIGN KEY (`id_tipo_justificacion`) REFERENCES `tc_janal_tipos_justificaciones` (`id_tipo_justificacion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_cfg_detalles_claves_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_configuraciones` */

DROP TABLE IF EXISTS `tc_janal_configuraciones`;

CREATE TABLE `tc_janal_configuraciones` (
  `id_configuracion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `llave` varchar(100) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(100) COLLATE latin1_bin NOT NULL,
  `valor` varchar(100) COLLATE latin1_bin NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_configuracion`),
  UNIQUE KEY `primary_42` (`id_configuracion`),
  KEY `tcikusu_tcikconfig_fk` (`id_usuario`),
  CONSTRAINT `tc_janal_configuraciones_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_contador_ayudas` */

DROP TABLE IF EXISTS `tc_janal_contador_ayudas`;

CREATE TABLE `tc_janal_contador_ayudas` (
  `id_contar_ayuda` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_ayuda` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contar_ayuda`),
  KEY `tc_contador_tc_ayudas` (`id_ayuda`),
  CONSTRAINT `tc_janal_contador_ayudas_ibfk_1` FOREIGN KEY (`id_ayuda`) REFERENCES `tc_janal_ayudas` (`id_ayuda`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=464 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_continentes` */

DROP TABLE IF EXISTS `tc_janal_continentes`;

CREATE TABLE `tc_janal_continentes` (
  `id_continente` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(50) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` bigint(11) unsigned NOT NULL,
  PRIMARY KEY (`id_continente`),
  KEY `tciktusu_tciktcon_fk` (`id_usuario`),
  CONSTRAINT `tc_janal_continentes_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_entidades` */

DROP TABLE IF EXISTS `tc_janal_entidades`;

CREATE TABLE `tc_janal_entidades` (
  `id_entidad` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_pais` bigint(11) unsigned NOT NULL,
  `siglas` varchar(5) COLLATE latin1_bin NOT NULL,
  `clave` varchar(2) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_entidad`),
  UNIQUE KEY `primary_71` (`id_entidad`),
  UNIQUE KEY `descripcion_10` (`descripcion`),
  KEY `id_pais` (`id_pais`),
  CONSTRAINT `tc_janal_entidades_ibfk_1` FOREIGN KEY (`id_pais`) REFERENCES `tc_janal_paises` (`id_pais`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_formatos` */

DROP TABLE IF EXISTS `tc_janal_formatos`;

CREATE TABLE `tc_janal_formatos` (
  `id_formato` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) COLLATE latin1_bin NOT NULL,
  `formato` varchar(50) COLLATE latin1_bin NOT NULL,
  PRIMARY KEY (`id_formato`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_grupos` */

DROP TABLE IF EXISTS `tc_janal_grupos`;

CREATE TABLE `tc_janal_grupos` (
  `id_grupo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(20) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_grupo`),
  UNIQUE KEY `primary_93` (`id_grupo`),
  UNIQUE KEY `tc_janal_grupos_uk` (`descripcion`,`clave`),
  KEY `tc_kajool_grupos_ibfk_1` (`id_usuario`),
  CONSTRAINT `tc_janal_grupos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_horas` */

DROP TABLE IF EXISTS `tc_janal_horas`;

CREATE TABLE `tc_janal_horas` (
  `id_hora` bigint(11) NOT NULL,
  `descripcion` varchar(2) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_insumos` */

DROP TABLE IF EXISTS `tc_janal_insumos`;

CREATE TABLE `tc_janal_insumos` (
  `id_insumo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `version` varchar(10) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `contenido` varchar(50) COLLATE latin1_bin NOT NULL,
  `descarga` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `orden` int(5) NOT NULL,
  `disponible` bigint(1) NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_insumo`),
  UNIQUE KEY `id_insumo` (`id_insumo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_localidades` */

DROP TABLE IF EXISTS `tc_janal_localidades`;

CREATE TABLE `tc_janal_localidades` (
  `id_localidad` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_municipio` bigint(11) unsigned NOT NULL,
  `clave` varchar(4) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_localidad`),
  UNIQUE KEY `id_entidad_1` (`id_municipio`,`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=322902 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_mensajes` */

DROP TABLE IF EXISTS `tc_janal_mensajes`;

CREATE TABLE `tc_janal_mensajes` (
  `id_mensaje` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(4000) COLLATE latin1_bin NOT NULL,
  `vigencia_ini` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vigencia_fin` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `id_tipo_mensaje` bigint(11) unsigned NOT NULL,
  `url_seguimiento` varchar(200) COLLATE latin1_bin NOT NULL,
  `id_prioridad` bigint(11) unsigned NOT NULL,
  `periodo` bigint(10) DEFAULT NULL,
  `periodo_repite` bigint(10) DEFAULT NULL,
  `fecha_repite` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nombre` varchar(150) COLLATE latin1_bin DEFAULT NULL,
  `actualizacion` varchar(1) COLLATE latin1_bin NOT NULL,
  `dias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario_modifica` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_mensaje`),
  UNIQUE KEY `primary_56` (`id_mensaje`),
  UNIQUE KEY `tc_janal_mensajes_uk1` (`registro`),
  KEY `id_prioridad` (`id_prioridad`),
  KEY `id_tipo_mensaje` (`id_tipo_mensaje`),
  KEY `id_usuario_10` (`id_usuario`),
  KEY `tc_janal_mensajes_ibfk_4` (`id_usuario_modifica`),
  CONSTRAINT `tc_janal_mensajes_ibfk_1` FOREIGN KEY (`id_tipo_mensaje`) REFERENCES `tc_janal_tipos_mensajes` (`id_tipo_mensaje`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_mensajes_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_mensajes_ibfk_3` FOREIGN KEY (`id_prioridad`) REFERENCES `tc_janal_prioridades` (`id_prioridad`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_menus` */

DROP TABLE IF EXISTS `tc_janal_menus`;

CREATE TABLE `tc_janal_menus` (
  `id_menu` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cfg_clave` bigint(11) unsigned NOT NULL,
  `clave` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin NOT NULL,
  `ruta` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `publicar` varchar(1) COLLATE latin1_bin DEFAULT NULL,
  `nivel` bigint(10) DEFAULT NULL,
  `ultimo` bigint(10) DEFAULT NULL,
  `ayuda` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `icono` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `codigo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_menu`),
  UNIQUE KEY `primary_102` (`id_menu`),
  KEY `tc_janal_menus_ibfk_1` (`id_cfg_clave`),
  KEY `tc_janal_menus_ibfk_2` (`id_usuario`),
  CONSTRAINT `tc_janal_menus_ibfk_1` FOREIGN KEY (`id_cfg_clave`) REFERENCES `tc_janal_cfg_claves` (`id_cfg_clave`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_menus_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_menus_encabezado` */

DROP TABLE IF EXISTS `tc_janal_menus_encabezado`;

CREATE TABLE `tc_janal_menus_encabezado` (
  `id_menu_encabezado` bigint(15) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(255) COLLATE latin1_bin NOT NULL,
  `ayuda` varchar(255) COLLATE latin1_bin NOT NULL,
  `icono` varchar(50) COLLATE latin1_bin NOT NULL,
  `publicar` int(1) NOT NULL,
  `nivel` int(2) NOT NULL,
  `ultimo` int(1) NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_menu_encabezado`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_meses` */

DROP TABLE IF EXISTS `tc_janal_meses`;

CREATE TABLE `tc_janal_meses` (
  `id_mes` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_mes`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_modulos` */

DROP TABLE IF EXISTS `tc_janal_modulos`;

CREATE TABLE `tc_janal_modulos` (
  `id_modulo` bigint(15) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_modulo`),
  UNIQUE KEY `tciktanmodulos_uk` (`descripcion`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_municipios` */

DROP TABLE IF EXISTS `tc_janal_municipios`;

CREATE TABLE `tc_janal_municipios` (
  `id_municipio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_entidad` bigint(11) unsigned NOT NULL,
  `clave` varchar(4) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_municipio`),
  UNIQUE KEY `primary_123` (`id_municipio`),
  UNIQUE KEY `id_entidad_1` (`id_entidad`,`clave`),
  CONSTRAINT `tc_janal_municipios_ibfk_1` FOREIGN KEY (`id_entidad`) REFERENCES `tc_janal_entidades` (`id_entidad`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2459 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_paises` */

DROP TABLE IF EXISTS `tc_janal_paises`;

CREATE TABLE `tc_janal_paises` (
  `id_pais` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_continente` bigint(11) unsigned NOT NULL,
  `siglas` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `clave` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pais`),
  UNIQUE KEY `primary_72` (`id_pais`),
  UNIQUE KEY `descripcion_7` (`descripcion`),
  KEY `tc_janal_paises_ibfk_1` (`id_usuario`),
  KEY `tciktcon_tciktpai_fk` (`id_continente`),
  CONSTRAINT `tc_janal_paises_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_paises_ibfk_2` FOREIGN KEY (`id_continente`) REFERENCES `tc_janal_continentes` (`id_continente`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=231 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_perfiles` */

DROP TABLE IF EXISTS `tc_janal_perfiles`;

CREATE TABLE `tc_janal_perfiles` (
  `id_perfil` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE latin1_bin NOT NULL,
  `id_grupo` bigint(11) unsigned NOT NULL,
  `id_menu` bigint(11) unsigned NOT NULL,
  `acceso` int(1) DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_perfil`),
  UNIQUE KEY `primary_73` (`id_perfil`),
  UNIQUE KEY `tc_janal_perfiles_uk1` (`descripcion`,`id_grupo`),
  KEY `tc_janal_perfiles_ibfk_2` (`id_usuario`),
  KEY `id_grupo` (`id_grupo`),
  KEY `id_menu` (`id_menu`),
  CONSTRAINT `tc_janal_perfiles_ibfk_1` FOREIGN KEY (`id_grupo`) REFERENCES `tc_janal_grupos` (`id_grupo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_perfiles_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_perfiles_ibfk_3` FOREIGN KEY (`id_menu`) REFERENCES `tc_janal_menus` (`id_menu`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_prioridades` */

DROP TABLE IF EXISTS `tc_janal_prioridades`;

CREATE TABLE `tc_janal_prioridades` (
  `id_prioridad` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(20) COLLATE latin1_bin NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_prioridad`),
  UNIQUE KEY `primary_74` (`id_prioridad`),
  KEY `tc_janal_prioridades_ibfk_1` (`id_usuario`),
  CONSTRAINT `tc_janal_prioridades_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_problematicas` */

DROP TABLE IF EXISTS `tc_janal_problematicas`;

CREATE TABLE `tc_janal_problematicas` (
  `id_problematica` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_problematica`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_proyectos` */

DROP TABLE IF EXISTS `tc_janal_proyectos`;

CREATE TABLE `tc_janal_proyectos` (
  `id_proyecto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_grupo` bigint(11) unsigned NOT NULL,
  `decripcion` varchar(500) COLLATE latin1_bin NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proyecto`),
  UNIQUE KEY `tciktanproyectos_uk` (`id_grupo`,`decripcion`,`id_empresa`),
  KEY `tcikusu_tcikproy_fk` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  CONSTRAINT `tc_janal_proyectos_ibfk_1` FOREIGN KEY (`id_grupo`) REFERENCES `tc_janal_grupos` (`id_grupo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_proyectos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_proyectos_ibfk_3` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_sesiones` */

DROP TABLE IF EXISTS `tc_janal_sesiones`;

CREATE TABLE `tc_janal_sesiones` (
  `id_sesion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `sesion` varchar(255) COLLATE latin1_bin NOT NULL,
  `path` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `inicio` datetime NOT NULL,
  `registro_inicio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `registro_fin` timestamp NULL DEFAULT NULL,
  `cuenta` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `tipo_acceso` bigint(11) DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_sesion`),
  UNIQUE KEY `tr_janal_sesiones_uk1` (`registro`,`cuenta`,`registro_fin`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_janal_sesiones_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_tablas` */

DROP TABLE IF EXISTS `tc_janal_tablas`;

CREATE TABLE `tc_janal_tablas` (
  `id_tabla` bigint(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) COLLATE latin1_bin NOT NULL,
  PRIMARY KEY (`id_tabla`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_tipos_datos` */

DROP TABLE IF EXISTS `tc_janal_tipos_datos`;

CREATE TABLE `tc_janal_tipos_datos` (
  `id_tipo_dato` bigint(11) unsigned NOT NULL DEFAULT '0',
  `entero` bigint(11) NOT NULL DEFAULT '0',
  `flotante` decimal(11,2) NOT NULL DEFAULT '0.00',
  `fecha` timestamp NULL DEFAULT NULL,
  `cadena` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` longblob,
  `relacion` bigint(11) DEFAULT NULL,
  `relacion_busqueda` bigint(11) DEFAULT NULL,
  `hora` datetime DEFAULT NULL,
  `texto` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `dtype` varchar(30) COLLATE latin1_bin DEFAULT NULL,
  `e_dato` varchar(20) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_dato`),
  UNIQUE KEY `tciktantiposdatos_uk` (`cadena`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_tipos_justificaciones` */

DROP TABLE IF EXISTS `tc_janal_tipos_justificaciones`;

CREATE TABLE `tc_janal_tipos_justificaciones` (
  `id_tipo_justificacion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) COLLATE latin1_bin NOT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_justificacion`),
  UNIQUE KEY `primary_124` (`id_tipo_justificacion`),
  KEY `tcikusu_tciktipjus_fk` (`id_usuario`),
  CONSTRAINT `tc_janal_tipos_justificaciones_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_tipos_mascaras` */

DROP TABLE IF EXISTS `tc_janal_tipos_mascaras`;

CREATE TABLE `tc_janal_tipos_mascaras` (
  `id_tipo_mascara` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE latin1_bin NOT NULL,
  `valor` varchar(255) COLLATE latin1_bin NOT NULL,
  PRIMARY KEY (`id_tipo_mascara`),
  UNIQUE KEY `tciktantiposmascaras_uk` (`valor`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_tipos_mensajes` */

DROP TABLE IF EXISTS `tc_janal_tipos_mensajes`;

CREATE TABLE `tc_janal_tipos_mensajes` (
  `id_tipo_mensaje` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE latin1_bin NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_mensaje`),
  UNIQUE KEY `primary_110` (`id_tipo_mensaje`),
  UNIQUE KEY `tc_janal_tipos_mensajes_uk1` (`descripcion`),
  KEY `tc_janal_tipos_mensajes_ibfk_1` (`id_usuario`),
  CONSTRAINT `tc_janal_tipos_mensajes_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_tipos_sexos` */

DROP TABLE IF EXISTS `tc_janal_tipos_sexos`;

CREATE TABLE `tc_janal_tipos_sexos` (
  `id_tipo_sexo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_sexo`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_tipos_validaciones` */

DROP TABLE IF EXISTS `tc_janal_tipos_validaciones`;

CREATE TABLE `tc_janal_tipos_validaciones` (
  `id_tipo_validacion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE latin1_bin NOT NULL,
  `valor` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_tipo_validacion`),
  UNIQUE KEY `tciktantiposvalidaciones_uk` (`descripcion`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_janal_usuarios` */

DROP TABLE IF EXISTS `tc_janal_usuarios`;

CREATE TABLE `tc_janal_usuarios` (
  `id_usuario` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_perfil` bigint(11) unsigned NOT NULL,
  `activo` bigint(10) NOT NULL DEFAULT '1',
  `id_usuario_modifica` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_persona` bigint(11) unsigned NOT NULL,
  `ultimo_acceso` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario`),
  KEY `tc_janal_usuarios_ibfk_1` (`id_perfil`),
  KEY `tc_janal_usuarios_ibfk_2` (`id_usuario_modifica`),
  KEY `tc_usuarios_persona` (`id_persona`),
  CONSTRAINT `tc_janal_usuarios_ibfk_1` FOREIGN KEY (`id_perfil`) REFERENCES `tc_janal_perfiles` (`id_perfil`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_janal_usuarios_ibfk_2` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_bitacoras` */

DROP TABLE IF EXISTS `tc_keet_bitacoras`;

CREATE TABLE `tc_keet_bitacoras` (
  `id_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `proceso` varchar(100) COLLATE latin1_bin NOT NULL,
  `tabla` varchar(100) COLLATE latin1_bin NOT NULL,
  `campo` varchar(100) COLLATE latin1_bin NOT NULL,
  `antes` varchar(500) COLLATE latin1_bin NOT NULL,
  `despues` varchar(500) COLLATE latin1_bin NOT NULL,
  `id_key` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bitacora`),
  KEY `id_key` (`id_key`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_bitacoras_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_bitacoras_alias` */

DROP TABLE IF EXISTS `tc_keet_bitacoras_alias`;

CREATE TABLE `tc_keet_bitacoras_alias` (
  `id_bitacora_alia` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `tabla` varchar(100) COLLATE latin1_bin NOT NULL,
  `campo` varchar(100) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bitacora_alia`),
  UNIQUE KEY `tabla` (`tabla`,`campo`,`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_clientes_contratos` */

DROP TABLE IF EXISTS `tc_keet_clientes_contratos`;

CREATE TABLE `tc_keet_clientes_contratos` (
  `id_cliente_contrato` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `clave` bigint(10) NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `recepcion` date DEFAULT NULL,
  `aceptacion` date DEFAULT NULL,
  `arranque` date DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_contrato`),
  UNIQUE KEY `id_cliente` (`id_cliente`,`clave`,`nombre`),
  KEY `id_cliente_2` (`id_cliente`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_clientes_contratos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_clientes_contratos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_constructivos` */

DROP TABLE IF EXISTS `tc_keet_constructivos`;

CREATE TABLE `tc_keet_constructivos` (
  `id_constructivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_grupo_constructivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_constructivo`),
  UNIQUE KEY `id_grupo_constructivo` (`id_grupo_constructivo`,`nombre`),
  KEY `id_grupo_constructivo_2` (`id_grupo_constructivo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_constructivos_ibfk_1` FOREIGN KEY (`id_grupo_constructivo`) REFERENCES `tc_keet_grupos_constructivos` (`id_grupo_constructivo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_contratos_archivos` */

DROP TABLE IF EXISTS `tc_keet_contratos_archivos`;

CREATE TABLE `tc_keet_contratos_archivos` (
  `id_contrato_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente_contrato` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contrato_archivo`),
  UNIQUE KEY `id_cliente_contrato_uk` (`id_cliente_contrato`,`id_tipo_archivo`,`nombre`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cliente_contrato` (`id_cliente_contrato`),
  CONSTRAINT `tc_keet_contratos_archivos_ibfk_1` FOREIGN KEY (`id_cliente_contrato`) REFERENCES `tc_keet_clientes_contratos` (`id_cliente_contrato`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_contratos_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_contratos_archivos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_contratos_proyectos` */

DROP TABLE IF EXISTS `tc_keet_contratos_proyectos`;

CREATE TABLE `tc_keet_contratos_proyectos` (
  `id_contrato_proyecto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente_contrato` bigint(11) unsigned NOT NULL,
  `clave` varchar(10) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `valor` decimal(11,4) DEFAULT '0.0000',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contrato_proyecto`),
  UNIQUE KEY `id_cliente_contrato` (`id_cliente_contrato`,`clave`,`nombre`),
  KEY `id_cliente_contrato_2` (`id_cliente_contrato`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_contratos_proyectos_ibfk_1` FOREIGN KEY (`id_cliente_contrato`) REFERENCES `tc_keet_clientes_contratos` (`id_cliente_contrato`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_contratos_proyectos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_departamentos` */

DROP TABLE IF EXISTS `tc_keet_departamentos`;

CREATE TABLE `tc_keet_departamentos` (
  `id_departamento` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_departamento`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_desarrollos` */

DROP TABLE IF EXISTS `tc_keet_desarrollos`;

CREATE TABLE `tc_keet_desarrollos` (
  `id_desarrollo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `clave` varchar(10) COLLATE latin1_bin NOT NULL,
  `nombres` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_domicilio` bigint(11) unsigned DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_desarrollo`),
  UNIQUE KEY `clave` (`clave`,`nombres`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `tc_keet_desarrollos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_desarrollos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_divisiones` */

DROP TABLE IF EXISTS `tc_keet_divisiones`;

CREATE TABLE `tc_keet_divisiones` (
  `id_division` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_division`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_especialidades` */

DROP TABLE IF EXISTS `tc_keet_especialidades`;

CREATE TABLE `tc_keet_especialidades` (
  `id_especialidad` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_especialidad`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_estaciones` */

DROP TABLE IF EXISTS `tc_keet_estaciones`;

CREATE TABLE `tc_keet_estaciones` (
  `id_estacion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_estacion`),
  KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_familias` */

DROP TABLE IF EXISTS `tc_keet_familias`;

CREATE TABLE `tc_keet_familias` (
  `id_familia` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_familia`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_grupos_constructivos` */

DROP TABLE IF EXISTS `tc_keet_grupos_constructivos`;

CREATE TABLE `tc_keet_grupos_constructivos` (
  `id_grupo_constructivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_grupo_constructivo`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_nominas` */

DROP TABLE IF EXISTS `tc_keet_nominas`;

CREATE TABLE `tc_keet_nominas` (
  `id_nomina` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_tipo_nomina` bigint(11) unsigned NOT NULL,
  `id_nomina_periodo` bigint(11) unsigned NOT NULL,
  `fecha_pago` date DEFAULT NULL,
  `fecha_dispersion` date DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nomina`),
  KEY `id_tipo_nomina` (`id_tipo_nomina`),
  KEY `id_nomina_periodo` (`id_nomina_periodo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_nominas_ibfk_1` FOREIGN KEY (`id_tipo_nomina`) REFERENCES `tc_keet_tipos_nominas` (`id_tipo_nomina`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_nominas_ibfk_2` FOREIGN KEY (`id_nomina_periodo`) REFERENCES `tc_keet_nominas_periodos` (`id_nomina_periodo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_nominas_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_nominas_bitacora` */

DROP TABLE IF EXISTS `tc_keet_nominas_bitacora`;

CREATE TABLE `tc_keet_nominas_bitacora` (
  `id_nomina_bitacota` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_nomina` bigint(11) unsigned NOT NULL,
  `id_nomina_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nomina_bitacota`),
  UNIQUE KEY `id_nomina_bitacota` (`id_nomina_bitacota`),
  KEY `id_nomina` (`id_nomina`),
  KEY `id_nomina_estatus` (`id_nomina_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_nominas_bitacora_ibfk_1` FOREIGN KEY (`id_nomina`) REFERENCES `tc_keet_nominas` (`id_nomina`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_nominas_bitacora_ibfk_2` FOREIGN KEY (`id_nomina_estatus`) REFERENCES `tc_keet_nominas_estatus` (`id_nomina_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_nominas_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_nominas_conceptos` */

DROP TABLE IF EXISTS `tc_keet_nominas_conceptos`;

CREATE TABLE `tc_keet_nominas_conceptos` (
  `id_nomina_concepto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_tipo_concepto` bigint(11) unsigned NOT NULL,
  `clave` varchar(10) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `inicio` date DEFAULT NULL,
  `termino` date DEFAULT NULL,
  `formula` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `aplicar` varchar(53) COLLATE latin1_bin DEFAULT NULL,
  `id_activo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nomina_concepto`),
  UNIQUE KEY `id_tipo_concepto` (`id_tipo_concepto`,`nombre`,`id_activo`,`clave`),
  KEY `id_tipo_concepto_2` (`id_tipo_concepto`),
  KEY `id_activo` (`id_activo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_nominas_conceptos_ibfk_1` FOREIGN KEY (`id_tipo_concepto`) REFERENCES `tc_keet_tipos_conceptos` (`id_tipo_concepto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_nominas_conceptos_ibfk_2` FOREIGN KEY (`id_activo`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_nominas_conceptos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_nominas_constantes` */

DROP TABLE IF EXISTS `tc_keet_nominas_constantes`;

CREATE TABLE `tc_keet_nominas_constantes` (
  `id_nomina_constante` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `siglas` varchar(10) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `inicio` date DEFAULT NULL,
  `termino` date DEFAULT NULL,
  `valor` decimal(11,4) DEFAULT '0.0000',
  `id_activo` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nomina_constante`),
  UNIQUE KEY `siglas` (`siglas`,`nombre`,`id_activo`),
  KEY `id_activo` (`id_activo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_nominas_constantes_ibfk_1` FOREIGN KEY (`id_activo`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_nominas_constantes_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_nominas_estatus` */

DROP TABLE IF EXISTS `tc_keet_nominas_estatus`;

CREATE TABLE `tc_keet_nominas_estatus` (
  `id_nomina_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nomina_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_keet_nominas_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_nominas_periodos` */

DROP TABLE IF EXISTS `tc_keet_nominas_periodos`;

CREATE TABLE `tc_keet_nominas_periodos` (
  `id_nomina_periodo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `inicio` date NOT NULL,
  `termino` date NOT NULL,
  `calculo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nomina_periodo`),
  UNIQUE KEY `ejercicio` (`ejercicio`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_nominas_personas` */

DROP TABLE IF EXISTS `tc_keet_nominas_personas`;

CREATE TABLE `tc_keet_nominas_personas` (
  `id_nomina_persona` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_nomina` bigint(11) unsigned NOT NULL,
  `id_persona` bigint(11) unsigned NOT NULL,
  `percepciones` decimal(11,4) unsigned NOT NULL DEFAULT '0.0000',
  `deducciones` decimal(11,4) DEFAULT '0.0000',
  `neto` decimal(11,4) DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nomina_persona`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_personas_bancos` */

DROP TABLE IF EXISTS `tc_keet_personas_bancos`;

CREATE TABLE `tc_keet_personas_bancos` (
  `id_persona_banco` bigint(11) unsigned NOT NULL,
  `id_persona` bigint(11) unsigned NOT NULL,
  `id_banco` bigint(11) unsigned NOT NULL,
  `cuenta` varchar(20) COLLATE latin1_bin NOT NULL,
  `clabe` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '2',
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_persona_banco`),
  UNIQUE KEY `id_persona` (`id_persona`,`id_banco`,`cuenta`),
  KEY `id_persona_2` (`id_persona`),
  KEY `id_banco` (`id_banco`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_principal` (`id_principal`),
  CONSTRAINT `tc_keet_personas_bancos_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_personas_bancos_ibfk_2` FOREIGN KEY (`id_banco`) REFERENCES `tc_mantic_bancos` (`id_banco`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_personas_bancos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_personas_bancos_ibfk_4` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_personas_beneficiarios` */

DROP TABLE IF EXISTS `tc_keet_personas_beneficiarios`;

CREATE TABLE `tc_keet_personas_beneficiarios` (
  `id_persona_beneficiario` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(11) unsigned NOT NULL,
  `nombre` varchar(100) COLLATE latin1_bin NOT NULL,
  `paterno` varchar(100) COLLATE latin1_bin NOT NULL,
  `materno` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `rfc` varchar(11) COLLATE latin1_bin DEFAULT NULL,
  `curp` varchar(18) COLLATE latin1_bin DEFAULT NULL,
  `id_tipo_parentesco` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_persona_beneficiario`),
  KEY `id_tipo_parentesco` (`id_tipo_parentesco`),
  KEY `id_usuario` (`id_usuario`),
  KEY `tc_keet_personas_beneficiarios_ibfk_3` (`id_persona`),
  CONSTRAINT `tc_keet_personas_beneficiarios_ibfk_1` FOREIGN KEY (`id_tipo_parentesco`) REFERENCES `tc_keet_tipos_parentescos` (`id_tipo_parentesco`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_personas_beneficiarios_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_personas_beneficiarios_ibfk_3` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_personas_conceptos` */

DROP TABLE IF EXISTS `tc_keet_personas_conceptos`;

CREATE TABLE `tc_keet_personas_conceptos` (
  `id_persona_concepto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(11) unsigned NOT NULL,
  `id_nomina_concepto` bigint(11) unsigned NOT NULL,
  `inicio` date DEFAULT NULL,
  `termino` date DEFAULT NULL,
  `formula` varchar(255) COLLATE latin1_bin DEFAULT '0.00',
  `contador` bigint(11) DEFAULT NULL,
  `parcialidades` bigint(11) DEFAULT NULL,
  `id_activo` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_persona_concepto`),
  UNIQUE KEY `id_persona` (`id_persona`,`id_nomina_concepto`,`inicio`,`id_activo`),
  KEY `id_persona_2` (`id_persona`),
  KEY `id_nomina_concepto` (`id_nomina_concepto`),
  KEY `id_activo` (`id_activo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_personas_conceptos_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_personas_conceptos_ibfk_2` FOREIGN KEY (`id_nomina_concepto`) REFERENCES `tc_keet_nominas_conceptos` (`id_nomina_concepto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_personas_conceptos_ibfk_3` FOREIGN KEY (`id_activo`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_personas_conceptos_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_planos` */

DROP TABLE IF EXISTS `tc_keet_planos`;

CREATE TABLE `tc_keet_planos` (
  `id_plano` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_especialidad` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `decripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_plano`),
  UNIQUE KEY `id_especialidad` (`id_especialidad`,`nombre`),
  KEY `id_especialidad_2` (`id_especialidad`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_planos_ibfk_1` FOREIGN KEY (`id_especialidad`) REFERENCES `tc_keet_especialidades` (`id_especialidad`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_prototipos` */

DROP TABLE IF EXISTS `tc_keet_prototipos`;

CREATE TABLE `tc_keet_prototipos` (
  `id_prototipo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `metros2` decimal(11,4) DEFAULT '0.0000',
  `id_constructivo` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_prototipo`),
  UNIQUE KEY `id_cliente` (`id_cliente`,`nombre`),
  KEY `id_cliente_2` (`id_cliente`),
  KEY `id_constructivo` (`id_constructivo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_prototipos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_prototipos_ibfk_2` FOREIGN KEY (`id_constructivo`) REFERENCES `tc_keet_constructivos` (`id_constructivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_prototipos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_prototipos_archivos` */

DROP TABLE IF EXISTS `tc_keet_prototipos_archivos`;

CREATE TABLE `tc_keet_prototipos_archivos` (
  `id_prototipo_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_prototipo` bigint(11) unsigned NOT NULL,
  `id_plano` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuarios` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_prototipo_archivo`),
  UNIQUE KEY `id_prototipo_uk` (`id_prototipo`,`id_plano`,`nombre`,`id_tipo_archivo`),
  KEY `id_plano` (`id_plano`),
  KEY `id_usuarios` (`id_usuarios`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_prototipo` (`id_prototipo`),
  CONSTRAINT `tc_keet_prototipos_archivos_ibfk_1` FOREIGN KEY (`id_prototipo`) REFERENCES `tc_keet_prototipos` (`id_prototipo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_prototipos_archivos_ibfk_2` FOREIGN KEY (`id_plano`) REFERENCES `tc_keet_planos` (`id_plano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_prototipos_archivos_ibfk_3` FOREIGN KEY (`id_usuarios`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_prototipos_archivos_ibfk_4` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_proyectos` */

DROP TABLE IF EXISTS `tc_keet_proyectos`;

CREATE TABLE `tc_keet_proyectos` (
  `id_proyecto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `id_desarrollo` bigint(11) unsigned NOT NULL,
  `id_tipos_obras` bigint(11) unsigned NOT NULL,
  `no_viviendas` bigint(11) DEFAULT '0',
  `etapa` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proyecto`),
  UNIQUE KEY `consecutivo` (`consecutivo`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_desarrollo` (`id_desarrollo`),
  KEY `id_tipos_obras` (`id_tipos_obras`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_proyectos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_ibfk_2` FOREIGN KEY (`id_desarrollo`) REFERENCES `tc_keet_desarrollos` (`id_desarrollo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_ibfk_3` FOREIGN KEY (`id_tipos_obras`) REFERENCES `tc_keet_tipos_obras` (`id_tipo_obra`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_proyectos_archivos` */

DROP TABLE IF EXISTS `tc_keet_proyectos_archivos`;

CREATE TABLE `tc_keet_proyectos_archivos` (
  `id_proyecto_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proyecto` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proyecto_archivo`),
  UNIQUE KEY `id_proyecto` (`id_proyecto`,`id_tipo_archivo`,`nombre`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_proyecto_2` (`id_proyecto`),
  CONSTRAINT `tc_keet_proyectos_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_archivos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_archivos_ibfk_4` FOREIGN KEY (`id_proyecto`) REFERENCES `tc_keet_proyectos` (`id_proyecto`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_proyectos_bitacora` */

DROP TABLE IF EXISTS `tc_keet_proyectos_bitacora`;

CREATE TABLE `tc_keet_proyectos_bitacora` (
  `id_proyecto_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proyecto_lote` bigint(11) unsigned NOT NULL,
  `id_proyecto_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proyecto_bitacora`),
  UNIQUE KEY `id_proyecto_bitacora` (`id_proyecto_bitacora`),
  KEY `id_proyecto_lote` (`id_proyecto_lote`),
  KEY `id_proyecto_estatus` (`id_proyecto_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_proyectos_bitacora_ibfk_1` FOREIGN KEY (`id_proyecto_lote`) REFERENCES `tc_keet_proyectos_lotes` (`id_proyecto_lote`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_bitacora_ibfk_2` FOREIGN KEY (`id_proyecto_estatus`) REFERENCES `tc_keet_proyectos_estatus` (`id_proyecto_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_proyectos_estatus` */

DROP TABLE IF EXISTS `tc_keet_proyectos_estatus`;

CREATE TABLE `tc_keet_proyectos_estatus` (
  `id_proyecto_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proyecto_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_keet_proyectos_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_proyectos_generadores` */

DROP TABLE IF EXISTS `tc_keet_proyectos_generadores`;

CREATE TABLE `tc_keet_proyectos_generadores` (
  `id_proyecto_generador` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proyecto` bigint(11) unsigned NOT NULL,
  `id_tipo_generador` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proyecto_generador`),
  UNIQUE KEY `id_proyecto_uk` (`id_proyecto`,`id_tipo_generador`,`nombre`,`id_tipo_archivo`),
  KEY `id_tipo_generador` (`id_tipo_generador`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_proyecto` (`id_proyecto`),
  CONSTRAINT `tc_keet_proyectos_generadores_ibfk_1` FOREIGN KEY (`id_proyecto`) REFERENCES `tc_keet_proyectos` (`id_proyecto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_generadores_ibfk_2` FOREIGN KEY (`id_tipo_generador`) REFERENCES `tc_keet_tipos_generadores` (`id_tipo_generador`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_generadores_ibfk_3` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_generadores_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_proyectos_lotes` */

DROP TABLE IF EXISTS `tc_keet_proyectos_lotes`;

CREATE TABLE `tc_keet_proyectos_lotes` (
  `id_proyecto_lote` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proyecto` bigint(11) unsigned NOT NULL,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_prototipo` bigint(11) unsigned NOT NULL,
  `manzana` varchar(10) COLLATE latin1_bin NOT NULL,
  `lote` bigint(11) NOT NULL,
  `id_tipo_fachada` bigint(11) unsigned NOT NULL,
  `atributos` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proyecto_lote`),
  UNIQUE KEY `id_proyecto` (`id_proyecto`,`manzana`,`lote`),
  KEY `id_proyecto_2` (`id_proyecto`),
  KEY `id_prototipo` (`id_prototipo`),
  KEY `id_tipo_fachada` (`id_tipo_fachada`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_proyectos_lotes_ibfk_1` FOREIGN KEY (`id_proyecto`) REFERENCES `tc_keet_proyectos` (`id_proyecto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_lotes_ibfk_2` FOREIGN KEY (`id_prototipo`) REFERENCES `tc_keet_prototipos` (`id_prototipo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_lotes_ibfk_3` FOREIGN KEY (`id_tipo_fachada`) REFERENCES `tc_keet_tipos_fachadas` (`id_tipo_fachada`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_lotes_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_proyectos_prespuestos` */

DROP TABLE IF EXISTS `tc_keet_proyectos_prespuestos`;

CREATE TABLE `tc_keet_proyectos_prespuestos` (
  `id_proyecto_presupuesto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proyecto` bigint(11) unsigned NOT NULL,
  `id_tipo_presupuesto` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuarios` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proyecto_presupuesto`),
  UNIQUE KEY `id_proyecto` (`id_proyecto`,`id_tipo_presupuesto`,`id_tipo_archivo`,`nombre`),
  KEY `id_proyecto_2` (`id_proyecto`),
  KEY `id_tipo_presupuesto` (`id_tipo_presupuesto`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuarios` (`id_usuarios`),
  CONSTRAINT `tc_keet_proyectos_prespuestos_ibfk_1` FOREIGN KEY (`id_proyecto`) REFERENCES `tc_keet_proyectos` (`id_proyecto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_prespuestos_ibfk_2` FOREIGN KEY (`id_tipo_presupuesto`) REFERENCES `tc_keet_tipos_presupuestos` (`id_tipo_presupuesto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_prespuestos_ibfk_3` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_keet_proyectos_prespuestos_ibfk_4` FOREIGN KEY (`id_usuarios`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_tipos_atributos` */

DROP TABLE IF EXISTS `tc_keet_tipos_atributos`;

CREATE TABLE `tc_keet_tipos_atributos` (
  `id_tipo_atributo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_atributo`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_tipos_conceptos` */

DROP TABLE IF EXISTS `tc_keet_tipos_conceptos`;

CREATE TABLE `tc_keet_tipos_conceptos` (
  `id_tipo_concepto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_concepto`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_tipos_fachadas` */

DROP TABLE IF EXISTS `tc_keet_tipos_fachadas`;

CREATE TABLE `tc_keet_tipos_fachadas` (
  `id_tipo_fachada` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_fachada`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_tipos_generadores` */

DROP TABLE IF EXISTS `tc_keet_tipos_generadores`;

CREATE TABLE `tc_keet_tipos_generadores` (
  `id_tipo_generador` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_estacion` bigint(11) unsigned NOT NULL,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_generador`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_estacion` (`id_estacion`),
  CONSTRAINT `tc_keet_tipos_generadores_ibfk_1` FOREIGN KEY (`id_estacion`) REFERENCES `tc_keet_estaciones` (`id_estacion`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_tipos_nominas` */

DROP TABLE IF EXISTS `tc_keet_tipos_nominas`;

CREATE TABLE `tc_keet_tipos_nominas` (
  `id_tipo_nomina` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_nomina`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_tipos_obras` */

DROP TABLE IF EXISTS `tc_keet_tipos_obras`;

CREATE TABLE `tc_keet_tipos_obras` (
  `id_tipo_obra` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_division` bigint(11) unsigned NOT NULL,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_obra`),
  UNIQUE KEY `id_division` (`id_division`,`nombre`),
  KEY `id_division_2` (`id_division`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_keet_tipos_obras_ibfk_1` FOREIGN KEY (`id_division`) REFERENCES `tc_keet_divisiones` (`id_division`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_tipos_parentescos` */

DROP TABLE IF EXISTS `tc_keet_tipos_parentescos`;

CREATE TABLE `tc_keet_tipos_parentescos` (
  `id_tipo_parentesco` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_parentesco`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_keet_tipos_presupuestos` */

DROP TABLE IF EXISTS `tc_keet_tipos_presupuestos`;

CREATE TABLE `tc_keet_tipos_presupuestos` (
  `id_tipo_presupuesto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_presupuesto`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_alertas` */

DROP TABLE IF EXISTS `tc_mantic_alertas`;

CREATE TABLE `tc_mantic_alertas` (
  `id_alerta` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_notifica` bigint(11) unsigned NOT NULL DEFAULT '1',
  `mensaje` varchar(800) COLLATE latin1_bin NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_alerta`),
  KEY `id_notifica` (`id_notifica`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_almacenes` */

DROP TABLE IF EXISTS `tc_mantic_almacenes`;

CREATE TABLE `tc_mantic_almacenes` (
  `id_almacen` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `clave` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_responsable` bigint(11) unsigned NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_almacen`),
  UNIQUE KEY `id_empresa_uk` (`id_empresa`,`nombre`),
  KEY `id_responsable` (`id_responsable`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_principal` (`id_principal`),
  CONSTRAINT `tc_mantic_almacenes_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_almacenes_ibfk_2` FOREIGN KEY (`id_responsable`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_almacenes_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_almacenes_articulos` */

DROP TABLE IF EXISTS `tc_mantic_almacenes_articulos`;

CREATE TABLE `tc_mantic_almacenes_articulos` (
  `id_almacen_articulo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_almacen` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `stock` decimal(11,2) NOT NULL DEFAULT '0.00',
  `minimo` decimal(11,2) NOT NULL DEFAULT '0.00',
  `maximo` decimal(11,2) NOT NULL DEFAULT '0.00',
  `id_almacen_ubicacion` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_almacen_articulo`),
  UNIQUE KEY `id_almacen_uk` (`id_almacen`,`id_articulo`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_almacen_ubicacion` (`id_almacen_ubicacion`),
  KEY `id_almacen` (`id_almacen`),
  CONSTRAINT `tc_mantic_almacenes_articulos_ibfk_1` FOREIGN KEY (`id_almacen`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_almacenes_articulos_ibfk_3` FOREIGN KEY (`id_almacen_ubicacion`) REFERENCES `tc_mantic_almacenes_ubicaciones` (`id_almacen_ubicacion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_almacenes_articulos_ibfk_4` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_almacenes_ubicaciones` */

DROP TABLE IF EXISTS `tc_mantic_almacenes_ubicaciones`;

CREATE TABLE `tc_mantic_almacenes_ubicaciones` (
  `id_almacen_ubicacion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_almacen` bigint(11) unsigned NOT NULL,
  `nivel` bigint(1) unsigned NOT NULL DEFAULT '1',
  `piso` varchar(100) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `cuarto` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `anaquel` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `charola` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_almacen_ubicacion`),
  UNIQUE KEY `id_almacen` (`id_almacen`,`piso`,`cuarto`,`anaquel`,`charola`),
  KEY `id_almacen_2` (`id_almacen`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_apartados` */

DROP TABLE IF EXISTS `tc_mantic_apartados`;

CREATE TABLE `tc_mantic_apartados` (
  `id_apartado` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_venta` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(100) COLLATE latin1_bin NOT NULL,
  `paterno` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `materno` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `telefono` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `celular` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `domicilio` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `importe` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `abonado` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `saldo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `id_apartado_estatus` bigint(11) unsigned NOT NULL DEFAULT '1',
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) DEFAULT NULL,
  `vencimiento` date DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_apartado`),
  KEY `id_venta` (`id_venta`,`materno`),
  CONSTRAINT `tc_mantic_apartados_ibfk_1` FOREIGN KEY (`id_venta`) REFERENCES `tc_mantic_ventas` (`id_venta`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_apartados_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_apartados_bitacora`;

CREATE TABLE `tc_mantic_apartados_bitacora` (
  `id_apartado_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_apartado` bigint(11) unsigned NOT NULL,
  `id_apartado_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `porcentaje_retenido` decimal(11,2) DEFAULT NULL,
  `cantidad_retenida` decimal(11,2) DEFAULT NULL,
  `importe_devuelto` decimal(11,2) DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_apartado_bitacora`),
  UNIQUE KEY `id_apartado_uk` (`id_apartado`,`id_apartado_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_apartado_estatus` (`id_apartado_estatus`),
  KEY `id_apartado` (`id_apartado`),
  CONSTRAINT `tc_mantic_apartados_bitacora_ibfk_1` FOREIGN KEY (`id_apartado`) REFERENCES `tc_mantic_apartados` (`id_apartado`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_apartados_bitacora_ibfk_2` FOREIGN KEY (`id_apartado_estatus`) REFERENCES `tc_mantic_apartados_estatus` (`id_apartado_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_apartados_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_apartados_estatus` */

DROP TABLE IF EXISTS `tc_mantic_apartados_estatus`;

CREATE TABLE `tc_mantic_apartados_estatus` (
  `id_apartado_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_apartado_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_apartados_pagos` */

DROP TABLE IF EXISTS `tc_mantic_apartados_pagos`;

CREATE TABLE `tc_mantic_apartados_pagos` (
  `id_apartado_pago` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_apartado` bigint(11) unsigned NOT NULL,
  `id_tipo_medio_pago` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_banco` bigint(11) unsigned DEFAULT NULL,
  `pago` decimal(11,4) DEFAULT '0.0000',
  `referencia` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_cierre` bigint(11) unsigned DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_apartado_pago`),
  UNIQUE KEY `id_apartado_uk` (`id_apartado`,`pago`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_tipo_medio_pago` (`id_tipo_medio_pago`),
  KEY `id_apartado` (`id_apartado`),
  KEY `id_cierre` (`id_cierre`),
  KEY `id_banco` (`id_banco`),
  CONSTRAINT `tc_mantic_apartados_pagos_ibfk_1` FOREIGN KEY (`id_apartado`) REFERENCES `tc_mantic_apartados` (`id_apartado`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_apartados_pagos_ibfk_2` FOREIGN KEY (`id_tipo_medio_pago`) REFERENCES `tc_mantic_tipos_medios_pagos` (`id_tipo_medio_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_apartados_pagos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_apartados_pagos_ibfk_4` FOREIGN KEY (`id_cierre`) REFERENCES `tc_mantic_cierres` (`id_cierre`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_apartados_pagos_ibfk_5` FOREIGN KEY (`id_banco`) REFERENCES `tc_mantic_bancos` (`id_banco`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_archivos` */

DROP TABLE IF EXISTS `tc_mantic_archivos`;

CREATE TABLE `tc_mantic_archivos` (
  `id_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `alias` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_eliminado` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_archivo`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_eliminado` (`id_eliminado`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_articulos` */

DROP TABLE IF EXISTS `tc_mantic_articulos`;

CREATE TABLE `tc_mantic_articulos` (
  `id_articulo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_empaque_unidad_medida` bigint(11) unsigned NOT NULL DEFAULT '1',
  `cantidad` bigint(11) DEFAULT '1',
  `iva` decimal(11,2) NOT NULL DEFAULT '16.00',
  `id_redondear` bigint(11) unsigned NOT NULL DEFAULT '1',
  `precio` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `menudeo` decimal(11,4) DEFAULT '0.0000',
  `medio_mayoreo` decimal(11,4) DEFAULT '0.0000',
  `mayoreo` decimal(11,4) DEFAULT '0.0000',
  `limite_medio_mayoreo` decimal(11,4) NOT NULL DEFAULT '10.0000',
  `limite_mayoreo` decimal(11,2) NOT NULL DEFAULT '20.00',
  `meta_tag` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `meta_tag_descipcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `meta_tag_teclado` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_imagen` bigint(11) unsigned DEFAULT NULL,
  `id_categoria` bigint(11) unsigned DEFAULT NULL,
  `descuentos` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `peso_estimado` decimal(11,2) NOT NULL DEFAULT '0.00',
  `extras` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `desperdicio` decimal(11,2) NOT NULL DEFAULT '0.00',
  `minimo` decimal(11,2) unsigned NOT NULL DEFAULT '3.00',
  `maximo` decimal(11,2) unsigned NOT NULL DEFAULT '10.00',
  `stock` decimal(11,2) NOT NULL DEFAULT '0.00',
  `sat` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_vigente` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_iva` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_articulo_tipo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_barras` bigint(11) unsigned NOT NULL DEFAULT '2',
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `extra` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `id_facturama` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unidad` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `codigo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `alterno` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `actualizado` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo`),
  UNIQUE KEY `nombre_uk` (`nombre`,`id_empaque_unidad_medida`,`id_empresa`),
  KEY `id_articulo_presentacion_medida` (`id_empaque_unidad_medida`),
  KEY `id_redondear` (`id_redondear`),
  KEY `id_imagen` (`id_imagen`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_vigente` (`id_vigente`),
  KEY `nombre` (`nombre`),
  KEY `id_iva` (`id_iva`),
  KEY `id_barras` (`id_barras`),
  KEY `id_articulo_tipo` (`id_articulo_tipo`),
  CONSTRAINT `tc_mantic_articulos_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_ibfk_10` FOREIGN KEY (`id_iva`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_ibfk_12` FOREIGN KEY (`id_barras`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_ibfk_13` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_ibfk_14` FOREIGN KEY (`id_articulo_tipo`) REFERENCES `tc_mantic_articulos_tipos` (`id_articulo_tipo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_ibfk_2` FOREIGN KEY (`id_redondear`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_ibfk_3` FOREIGN KEY (`id_imagen`) REFERENCES `tc_mantic_imagenes` (`id_imagen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_ibfk_5` FOREIGN KEY (`id_categoria`) REFERENCES `tc_mantic_categorias` (`id_categoria`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_ibfk_8` FOREIGN KEY (`id_empaque_unidad_medida`) REFERENCES `tr_mantic_empaque_unidad_medida` (`id_empaque_unidad_medida`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_ibfk_9` FOREIGN KEY (`id_vigente`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_articulos_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_articulos_bitacora`;

CREATE TABLE `tc_mantic_articulos_bitacora` (
  `id_articulo_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `id_nota_entrada` bigint(11) unsigned DEFAULT NULL,
  `cantidad` decimal(11,2) NOT NULL,
  `costo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `menudeo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `medio_mayoreo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `mayoreo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `iva` decimal(11,4) NOT NULL DEFAULT '16.0000',
  `limite_medio_mayoreo` decimal(11,4) DEFAULT '0.0000',
  `limite_mayoreo` decimal(11,4) DEFAULT '0.0000',
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `extras` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_bitacora`),
  UNIQUE KEY `id_articulo_uk` (`id_articulo`,`id_nota_entrada`,`registro`),
  KEY `id_nota_entrada` (`id_nota_entrada`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_articulo` (`id_articulo`),
  CONSTRAINT `tc_mantic_articulos_bitacora_ibfk_2` FOREIGN KEY (`id_nota_entrada`) REFERENCES `tc_mantic_notas_entradas` (`id_nota_entrada`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_bitacora_ibfk_4` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_articulos_codigos` */

DROP TABLE IF EXISTS `tc_mantic_articulos_codigos`;

CREATE TABLE `tc_mantic_articulos_codigos` (
  `id_articulo_codigo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `codigo` varchar(255) COLLATE latin1_bin NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_proveedor` bigint(11) unsigned DEFAULT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_codigo`),
  UNIQUE KEY `id_articulo` (`id_articulo`,`codigo`,`id_proveedor`,`id_principal`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_principal` (`id_principal`),
  KEY `codigo` (`codigo`),
  KEY `id_articulo_2` (`id_articulo`,`codigo`,`id_proveedor`),
  KEY `id_articulo_3` (`id_articulo`,`codigo`),
  CONSTRAINT `tc_mantic_articulos_codigos_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_codigos_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_articulos_codigos_ibfk_5` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_articulos_descuentos` */

DROP TABLE IF EXISTS `tc_mantic_articulos_descuentos`;

CREATE TABLE `tc_mantic_articulos_descuentos` (
  `id_articulo_descuento` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `porcentaje` decimal(11,2) NOT NULL DEFAULT '0.00',
  `vigencia_inicial` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vigencia_final` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_descuento`),
  UNIQUE KEY `porcentaje` (`porcentaje`,`vigencia_inicial`,`vigencia_final`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_articulo` (`id_articulo`),
  CONSTRAINT `tc_mantic_articulos_descuentos_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_articulos_dimenciones` */

DROP TABLE IF EXISTS `tc_mantic_articulos_dimenciones`;

CREATE TABLE `tc_mantic_articulos_dimenciones` (
  `id_articulo_dimension` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `ancho` bigint(11) NOT NULL DEFAULT '0',
  `largo` bigint(11) NOT NULL DEFAULT '0',
  `alto` bigint(11) NOT NULL DEFAULT '0',
  `observaciones` varbinary(500) DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_dimension`),
  UNIQUE KEY `id_articulo` (`id_articulo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_articulos_dimenciones_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_articulos_especificaciones` */

DROP TABLE IF EXISTS `tc_mantic_articulos_especificaciones`;

CREATE TABLE `tc_mantic_articulos_especificaciones` (
  `id_articulo_especificacion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `valor` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_especificacion`),
  UNIQUE KEY `nombre` (`nombre`,`id_articulo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_articulo` (`id_articulo`),
  CONSTRAINT `tc_mantic_articulos_especificaciones_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_articulos_tipos` */

DROP TABLE IF EXISTS `tc_mantic_articulos_tipos`;

CREATE TABLE `tc_mantic_articulos_tipos` (
  `id_articulo_tipo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_tipo`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_bancos` */

DROP TABLE IF EXISTS `tc_mantic_bancos`;

CREATE TABLE `tc_mantic_bancos` (
  `id_banco` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `razon_social` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_banco`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_cajas` */

DROP TABLE IF EXISTS `tc_mantic_cajas`;

CREATE TABLE `tc_mantic_cajas` (
  `id_caja` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `clave` varchar(100) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `limite` decimal(11,2) DEFAULT '0.00',
  `id_activa` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_caja`),
  UNIQUE KEY `id_empresa_uk` (`id_empresa`,`clave`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_activa` (`id_activa`),
  CONSTRAINT `tc_mantic_cajas_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cajas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cajas_ibfk_3` FOREIGN KEY (`id_activa`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_cargos_compras` */

DROP TABLE IF EXISTS `tc_mantic_cargos_compras`;

CREATE TABLE `tc_mantic_cargos_compras` (
  `id_cargo_compra` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cargo_compra`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_categorias` */

DROP TABLE IF EXISTS `tc_mantic_categorias`;

CREATE TABLE `tc_mantic_categorias` (
  `id_categoria` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_cfg_claves` bigint(11) unsigned NOT NULL,
  `clave` varchar(255) COLLATE latin1_bin NOT NULL,
  `nivel` bigint(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `traza` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `clave` (`clave`),
  KEY `id_configuracion` (`id_cfg_claves`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  CONSTRAINT `tc_mantic_categorias_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_categorias_ibfk_2` FOREIGN KEY (`id_cfg_claves`) REFERENCES `tc_janal_cfg_claves` (`id_cfg_clave`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_cierres` */

DROP TABLE IF EXISTS `tc_mantic_cierres`;

CREATE TABLE `tc_mantic_cierres` (
  `id_cierre` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `id_diferencias` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_cierre_estatus` bigint(11) unsigned NOT NULL DEFAULT '1',
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `termino` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cierre`),
  UNIQUE KEY `id_ejercicio` (`ejercicio`,`orden`),
  KEY `id_diferencias` (`id_diferencias`),
  KEY `id_cierre_estatus` (`id_cierre_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_cierres_ibfk_2` FOREIGN KEY (`id_diferencias`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_ibfk_4` FOREIGN KEY (`id_cierre_estatus`) REFERENCES `tc_mantic_cierres_estatus` (`id_cierre_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_ibfk_5` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_cierres_alertas` */

DROP TABLE IF EXISTS `tc_mantic_cierres_alertas`;

CREATE TABLE `tc_mantic_cierres_alertas` (
  `id_cierre_alerta` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cierre` bigint(11) unsigned NOT NULL,
  `id_notifica` bigint(11) unsigned NOT NULL DEFAULT '1',
  `mensaje` varchar(500) COLLATE latin1_bin NOT NULL,
  `importe` decimal(11,4) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cierre_alerta`),
  KEY `id_notifica` (`id_notifica`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cierre` (`id_cierre`),
  CONSTRAINT `tc_mantic_cierres_alertas_ibfk_2` FOREIGN KEY (`id_notifica`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_alertas_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_alertas_ibfk_4` FOREIGN KEY (`id_cierre`) REFERENCES `tc_mantic_cierres` (`id_cierre`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_cierres_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_cierres_bitacora`;

CREATE TABLE `tc_mantic_cierres_bitacora` (
  `id_cierre_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cierre` bigint(11) unsigned NOT NULL,
  `id_cierre_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cierre_bitacora`),
  UNIQUE KEY `id_cierre_uk` (`id_cierre`,`id_cierre_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cierre_estatus` (`id_cierre_estatus`),
  KEY `id_cierre` (`id_cierre`),
  CONSTRAINT `tc_mantic_cierres_bitacora_ibfk_2` FOREIGN KEY (`id_cierre_estatus`) REFERENCES `tc_mantic_cierres_estatus` (`id_cierre_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_bitacora_ibfk_3` FOREIGN KEY (`id_cierre`) REFERENCES `tc_mantic_cierres` (`id_cierre`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_cierres_cajas` */

DROP TABLE IF EXISTS `tc_mantic_cierres_cajas`;

CREATE TABLE `tc_mantic_cierres_cajas` (
  `id_cierre_caja` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cierre` bigint(11) unsigned NOT NULL,
  `id_caja` bigint(11) unsigned NOT NULL,
  `id_tipo_medio_pago` bigint(11) unsigned NOT NULL,
  `dia` date NOT NULL,
  `disponible` decimal(11,4) DEFAULT '0.0000',
  `acumulado` decimal(11,4) DEFAULT '0.0000',
  `saldo` decimal(11,4) DEFAULT '0.0000',
  `importe` decimal(11,4) DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cierre_caja`),
  KEY `id_caja` (`id_caja`),
  KEY `id_tipo_medio_pago` (`id_tipo_medio_pago`),
  KEY `id_cierre` (`id_cierre`),
  CONSTRAINT `tc_mantic_cierres_cajas_ibfk_1` FOREIGN KEY (`id_caja`) REFERENCES `tc_mantic_cajas` (`id_caja`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_cajas_ibfk_2` FOREIGN KEY (`id_tipo_medio_pago`) REFERENCES `tc_mantic_tipos_medios_pagos` (`id_tipo_medio_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_cajas_ibfk_4` FOREIGN KEY (`id_cierre`) REFERENCES `tc_mantic_cierres` (`id_cierre`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_cierres_estatus` */

DROP TABLE IF EXISTS `tc_mantic_cierres_estatus`;

CREATE TABLE `tc_mantic_cierres_estatus` (
  `id_cierre_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cierre_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_cierres_monedas` */

DROP TABLE IF EXISTS `tc_mantic_cierres_monedas`;

CREATE TABLE `tc_mantic_cierres_monedas` (
  `id_cierre_moneda` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cierre` bigint(11) unsigned NOT NULL,
  `id_moneda` bigint(11) unsigned NOT NULL,
  `cantidad` bigint(11) NOT NULL DEFAULT '0',
  `importe` decimal(11,4) DEFAULT '0.0000',
  `id_efectivo` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cierre_moneda`),
  UNIQUE KEY `id_cierre_uk` (`id_cierre`,`id_moneda`,`id_efectivo`),
  KEY `id_moneda` (`id_moneda`),
  KEY `id_cierre` (`id_cierre`),
  KEY `id_efectivo` (`id_efectivo`),
  CONSTRAINT `tc_mantic_cierres_monedas_ibfk_1` FOREIGN KEY (`id_cierre`) REFERENCES `tc_mantic_cierres` (`id_cierre`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_monedas_ibfk_2` FOREIGN KEY (`id_moneda`) REFERENCES `tc_mantic_monedas` (`id_moneda`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_monedas_ibfk_3` FOREIGN KEY (`id_efectivo`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_cierres_retiros` */

DROP TABLE IF EXISTS `tc_mantic_cierres_retiros`;

CREATE TABLE `tc_mantic_cierres_retiros` (
  `id_cierre_retiro` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cierre_caja` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `importe` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `concepto` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_abono` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_tipo_medio_pago` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_terminado` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `id_autorizo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cierre_retiro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cierre_caja` (`id_cierre_caja`),
  KEY `id_abono` (`id_abono`),
  KEY `id_tipo_medio_pago` (`id_tipo_medio_pago`),
  KEY `id_terminado` (`id_terminado`),
  KEY `id_autorizo` (`id_autorizo`),
  CONSTRAINT `tc_mantic_cierres_retiros_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_retiros_ibfk_4` FOREIGN KEY (`id_cierre_caja`) REFERENCES `tc_mantic_cierres_cajas` (`id_cierre_caja`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_retiros_ibfk_5` FOREIGN KEY (`id_abono`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_retiros_ibfk_6` FOREIGN KEY (`id_tipo_medio_pago`) REFERENCES `tc_mantic_tipos_medios_pagos` (`id_tipo_medio_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_retiros_ibfk_7` FOREIGN KEY (`id_terminado`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_cierres_retiros_ibfk_8` FOREIGN KEY (`id_autorizo`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_clientes` */

DROP TABLE IF EXISTS `tc_mantic_clientes`;

CREATE TABLE `tc_mantic_clientes` (
  `id_cliente` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `clave` varchar(50) COLLATE latin1_bin NOT NULL,
  `rfc` varchar(13) COLLATE latin1_bin DEFAULT NULL,
  `razon_social` varchar(255) COLLATE latin1_bin NOT NULL,
  `limite_credito` decimal(11,2) NOT NULL DEFAULT '0.00',
  `plazo_dias` bigint(11) NOT NULL DEFAULT '30',
  `id_tipo_venta` bigint(11) unsigned NOT NULL DEFAULT '1',
  `saldo` decimal(11,2) DEFAULT '0.00',
  `id_credito` bigint(11) unsigned NOT NULL DEFAULT '2',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_uso_cfdi` bigint(11) unsigned DEFAULT '3',
  `id_facturama` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente`),
  KEY `id_usuarios` (`id_usuario`),
  KEY `id_tipo_venta` (`id_tipo_venta`),
  KEY `id_empresa_uk` (`id_empresa`,`clave`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_credito` (`id_credito`),
  CONSTRAINT `tc_mantic_clientes_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_ibfk_2` FOREIGN KEY (`id_tipo_venta`) REFERENCES `tc_mantic_tipos_ventas` (`id_tipo_venta`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_ibfk_3` FOREIGN KEY (`id_credito`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3631 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_clientes_archivos` */

DROP TABLE IF EXISTS `tc_mantic_clientes_archivos`;

CREATE TABLE `tc_mantic_clientes_archivos` (
  `id_cliente_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente_representante` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_archivo`),
  UNIQUE KEY `id_cliente_uk` (`id_cliente_representante`,`id_tipo_archivo`,`nombre`,`ruta`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_principal` (`id_principal`),
  KEY `id_cliente_representante` (`id_cliente_representante`),
  CONSTRAINT `tc_mantic_clientes_archivos_ibfk_1` FOREIGN KEY (`id_cliente_representante`) REFERENCES `tr_mantic_cliente_representante` (`id_cliente_representante`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_archivos_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_clientes_deudas` */

DROP TABLE IF EXISTS `tc_mantic_clientes_deudas`;

CREATE TABLE `tc_mantic_clientes_deudas` (
  `id_cliente_deuda` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `id_venta` bigint(11) unsigned NOT NULL,
  `importe` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `saldo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `limite` date NOT NULL,
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_cliente_estatus` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_deuda`),
  UNIQUE KEY `id_cliente_uk` (`id_cliente`,`id_venta`,`importe`,`registro`),
  KEY `id_venta` (`id_venta`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_cliente_estatus` (`id_cliente_estatus`),
  KEY `registro` (`registro`),
  CONSTRAINT `tc_mantic_clientes_deudas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_deudas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_deudas_ibfk_3` FOREIGN KEY (`id_venta`) REFERENCES `tc_mantic_ventas` (`id_venta`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_deudas_ibfk_4` FOREIGN KEY (`id_cliente_estatus`) REFERENCES `tc_mantic_clientes_estatus` (`id_cliente_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_clientes_estatus` */

DROP TABLE IF EXISTS `tc_mantic_clientes_estatus`;

CREATE TABLE `tc_mantic_clientes_estatus` (
  `id_cliente_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_clientes_pagos` */

DROP TABLE IF EXISTS `tc_mantic_clientes_pagos`;

CREATE TABLE `tc_mantic_clientes_pagos` (
  `id_cliente_pago` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cierre` bigint(11) unsigned DEFAULT NULL,
  `id_cliente_deuda` bigint(11) unsigned NOT NULL,
  `id_tipo_medio_pago` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_banco` bigint(11) unsigned DEFAULT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL DEFAULT '201900001',
  `pago` decimal(11,4) DEFAULT '0.0000',
  `referencia` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ejercicio` bigint(11) unsigned NOT NULL DEFAULT '2019',
  `orden` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_pago`),
  UNIQUE KEY `id_cliente_deuda_uk` (`id_cliente_deuda`,`pago`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cliente_deuda` (`id_cliente_deuda`),
  KEY `id_tipo_medio_pago` (`id_tipo_medio_pago`),
  KEY `id_cierre` (`id_cierre`),
  KEY `id_banco` (`id_banco`),
  CONSTRAINT `tc_mantic_clientes_pagos_ibfk_1` FOREIGN KEY (`id_cliente_deuda`) REFERENCES `tc_mantic_clientes_deudas` (`id_cliente_deuda`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_pagos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_pagos_ibfk_3` FOREIGN KEY (`id_tipo_medio_pago`) REFERENCES `tc_mantic_tipos_medios_pagos` (`id_tipo_medio_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_pagos_ibfk_4` FOREIGN KEY (`id_cierre`) REFERENCES `tc_mantic_cierres` (`id_cierre`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_pagos_ibfk_5` FOREIGN KEY (`id_banco`) REFERENCES `tc_mantic_bancos` (`id_banco`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_clientes_pagos_archivos` */

DROP TABLE IF EXISTS `tc_mantic_clientes_pagos_archivos`;

CREATE TABLE `tc_mantic_clientes_pagos_archivos` (
  `id_cliente_pago_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente_pago` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_pago_archivo`),
  UNIQUE KEY `id_cliente_uk` (`id_cliente_pago`,`id_tipo_archivo`,`nombre`,`ruta`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_principal` (`id_principal`),
  KEY `id_cliente_representante` (`id_cliente_pago`),
  CONSTRAINT `tc_mantic_clientes_pagos_archivos_ibfk_1` FOREIGN KEY (`id_cliente_pago`) REFERENCES `tc_mantic_clientes_pagos` (`id_cliente_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_pagos_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_pagos_archivos_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_clientes_pagos_archivos_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_codigos_postales` */

DROP TABLE IF EXISTS `tc_mantic_codigos_postales`;

CREATE TABLE `tc_mantic_codigos_postales` (
  `id_codigo_postal` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_entidad` bigint(11) unsigned NOT NULL,
  `codigo` varchar(5) COLLATE latin1_bin NOT NULL,
  `municipio` varchar(3) COLLATE latin1_bin DEFAULT NULL,
  `localidad` varchar(4) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_codigo_postal`),
  KEY `id_entidad` (`id_entidad`),
  CONSTRAINT `tc_mantic_codigos_postales_ibfk_1` FOREIGN KEY (`id_entidad`) REFERENCES `tc_janal_entidades` (`id_entidad`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=95779 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_confrontas` */

DROP TABLE IF EXISTS `tc_mantic_confrontas`;

CREATE TABLE `tc_mantic_confrontas` (
  `id_confronta` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_transferencia` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_confronta`),
  UNIQUE KEY `id_transferencia_uk` (`id_transferencia`),
  KEY `id_transferencia` (`id_transferencia`),
  KEY `id_confronta` (`id_confronta`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_confrontas_ibfk_1` FOREIGN KEY (`id_transferencia`) REFERENCES `tc_mantic_transferencias` (`id_transferencia`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_confrontas_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_confrontas_detalles` */

DROP TABLE IF EXISTS `tc_mantic_confrontas_detalles`;

CREATE TABLE `tc_mantic_confrontas_detalles` (
  `id_confronta_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_confronta` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `codigo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `cantidad` decimal(11,4) DEFAULT '0.0000',
  `id_transferencia_detalle` bigint(11) unsigned DEFAULT NULL,
  `id_aplicar` bigint(11) unsigned NOT NULL DEFAULT '1',
  `cantidades` decimal(11,4) DEFAULT '0.0000',
  `declarados` decimal(11,4) DEFAULT '0.0000',
  `diferencia` decimal(11,4) DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_confronta_detalle`),
  UNIQUE KEY `id_confronta_uk` (`id_confronta`,`id_articulo`),
  KEY `id_confronta` (`id_confronta`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_transferencia_detalle` (`id_transferencia_detalle`),
  KEY `id_aplicar` (`id_aplicar`),
  CONSTRAINT `tc_mantic_confrontas_detalles_ibfk_1` FOREIGN KEY (`id_confronta`) REFERENCES `tc_mantic_confrontas` (`id_confronta`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_confrontas_detalles_ibfk_2` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_confrontas_detalles_ibfk_3` FOREIGN KEY (`id_transferencia_detalle`) REFERENCES `tc_mantic_transferencias_detalles` (`id_transferencia_detalle`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_control_descargas` */

DROP TABLE IF EXISTS `tc_mantic_control_descargas`;

CREATE TABLE `tc_mantic_control_descargas` (
  `id_control_descarga` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `id_respaldo` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_control_descarga`),
  UNIQUE KEY `id_usuario` (`id_usuario`,`id_respaldo`,`registro`),
  KEY `id_respaldo` (`id_respaldo`),
  CONSTRAINT `tc_mantic_control_descargas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_control_descargas_ibfk_2` FOREIGN KEY (`id_respaldo`) REFERENCES `tc_mantic_respaldos` (`id_respaldo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_control_respaldos` */

DROP TABLE IF EXISTS `tc_mantic_control_respaldos`;

CREATE TABLE `tc_mantic_control_respaldos` (
  `id_control_respaldo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_respaldo` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_control_respaldo`),
  UNIQUE KEY `id_respaldo_uk` (`id_respaldo`,`id_usuario`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_control_respaldos_ibfk_1` FOREIGN KEY (`id_respaldo`) REFERENCES `tc_mantic_respaldos` (`id_respaldo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_control_respaldos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_creditos_archivos` */

DROP TABLE IF EXISTS `tc_mantic_creditos_archivos`;

CREATE TABLE `tc_mantic_creditos_archivos` (
  `id_credito_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_credito_nota` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `mes` bigint(11) NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_credito_archivo`),
  UNIQUE KEY `id_credito_nota_uk` (`id_credito_nota`,`id_tipo_archivo`,`nombre`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_credito_nota` (`id_credito_nota`),
  KEY `id_principal` (`id_principal`),
  CONSTRAINT `tc_mantic_creditos_archivos_ibfk_1` FOREIGN KEY (`id_credito_nota`) REFERENCES `tc_mantic_creditos_notas` (`id_credito_nota`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_archivos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_archivos_ibfk_4` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_creditos_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_creditos_bitacora`;

CREATE TABLE `tc_mantic_creditos_bitacora` (
  `id_credito_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_credito_nota` bigint(11) unsigned NOT NULL,
  `id_credito_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `importe` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_credito_bitacora`),
  UNIQUE KEY `id_credito_uk` (`id_credito_nota`,`id_credito_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_credito_nota` (`id_credito_nota`),
  KEY `id_credito_estatus` (`id_credito_estatus`),
  CONSTRAINT `tc_mantic_creditos_bitacora_ibfk_1` FOREIGN KEY (`id_credito_nota`) REFERENCES `tc_mantic_creditos_notas` (`id_credito_nota`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_bitacora_ibfk_2` FOREIGN KEY (`id_credito_estatus`) REFERENCES `tc_mantic_creditos_estatus` (`id_credito_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_creditos_estatus` */

DROP TABLE IF EXISTS `tc_mantic_creditos_estatus`;

CREATE TABLE `tc_mantic_creditos_estatus` (
  `id_credito_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_credito_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_creditos_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_creditos_notas` */

DROP TABLE IF EXISTS `tc_mantic_creditos_notas`;

CREATE TABLE `tc_mantic_creditos_notas` (
  `id_credito_nota` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_devolucion` bigint(11) unsigned DEFAULT NULL,
  `id_nota_entrada` bigint(20) unsigned DEFAULT NULL,
  `id_proveedor` bigint(11) unsigned DEFAULT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `folio` varchar(255) COLLATE latin1_bin NOT NULL,
  `fecha` date DEFAULT NULL,
  `importe` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_credito_estatus` bigint(11) unsigned NOT NULL,
  `id_tipo_credito_nota` bigint(11) unsigned NOT NULL DEFAULT '1',
  `saldo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_credito_nota`),
  UNIQUE KEY `id_devolucion_uk` (`id_devolucion`,`folio`,`id_nota_entrada`,`id_proveedor`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_devolucion` (`id_devolucion`,`id_empresa`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_credito_estatus` (`id_credito_estatus`),
  KEY `id_nota_entrada` (`id_nota_entrada`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_tipo_credito_nota` (`id_tipo_credito_nota`),
  CONSTRAINT `tc_mantic_creditos_notas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_notas_ibfk_3` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_notas_ibfk_4` FOREIGN KEY (`id_credito_estatus`) REFERENCES `tc_mantic_creditos_estatus` (`id_credito_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_notas_ibfk_5` FOREIGN KEY (`id_devolucion`) REFERENCES `tc_mantic_devoluciones` (`id_devolucion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_notas_ibfk_6` FOREIGN KEY (`id_tipo_credito_nota`) REFERENCES `tc_mantic_tipos_creditos_notas` (`id_tipo_credito_nota`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_notas_ibfk_7` FOREIGN KEY (`id_nota_entrada`) REFERENCES `tc_mantic_notas_entradas` (`id_nota_entrada`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_creditos_notas_ibfk_8` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_descargas` */

DROP TABLE IF EXISTS `tc_mantic_descargas`;

CREATE TABLE `tc_mantic_descargas` (
  `id_descarga` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(765) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `ruta` varchar(1500) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `alias` varchar(765) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `observaciones` varchar(1500) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `id_usuario` bigint(11) DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `eliminado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activo` bigint(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_descarga`),
  KEY `activo` (`activo`),
  CONSTRAINT `tc_mantic_descargas_ibfk_1` FOREIGN KEY (`activo`) REFERENCES `tc_janal_booleanos` (`id_booleano`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_devoluciones` */

DROP TABLE IF EXISTS `tc_mantic_devoluciones`;

CREATE TABLE `tc_mantic_devoluciones` (
  `id_devolucion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_nota_entrada` bigint(11) unsigned DEFAULT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `sub_total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `descuento` varchar(100) COLLATE latin1_bin NOT NULL,
  `extras` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `id_devolucion_estatus` bigint(11) unsigned DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_devolucion`),
  UNIQUE KEY `id_empresa_uk` (`id_empresa`,`id_nota_entrada`,`ejercicio`,`orden`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_devolucion_estatus` (`id_devolucion_estatus`),
  KEY `id_nota_entrada` (`id_nota_entrada`),
  CONSTRAINT `tc_mantic_devoluciones_ibfk_1` FOREIGN KEY (`id_nota_entrada`) REFERENCES `tc_mantic_notas_entradas` (`id_nota_entrada`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_devoluciones_ibfk_2` FOREIGN KEY (`id_devolucion_estatus`) REFERENCES `tc_mantic_devoluciones_estatus` (`id_devolucion_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_devoluciones_ibfk_3` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_devoluciones_archivos` */

DROP TABLE IF EXISTS `tc_mantic_devoluciones_archivos`;

CREATE TABLE `tc_mantic_devoluciones_archivos` (
  `id_devolucion_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_devolucion` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_devolucion_archivo`),
  UNIQUE KEY `id_devolucion_uk` (`id_devolucion`,`id_tipo_archivo`,`nombre`,`ruta`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_principal` (`id_principal`),
  KEY `id_cliente_representante` (`id_devolucion`),
  CONSTRAINT `tc_mantic_devoluciones_archivos_ibfk_1` FOREIGN KEY (`id_devolucion`) REFERENCES `tc_mantic_devoluciones` (`id_devolucion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_devoluciones_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_devoluciones_archivos_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_devoluciones_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_devoluciones_bitacora`;

CREATE TABLE `tc_mantic_devoluciones_bitacora` (
  `id_devolucion_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_devolucion` bigint(11) unsigned NOT NULL,
  `id_devolucion_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `importe` decimal(11,2) NOT NULL DEFAULT '0.00',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_devolucion_bitacora`),
  UNIQUE KEY `id_devolucion_uk` (`id_devolucion`,`id_devolucion_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_devolucion` (`id_devolucion`),
  KEY `id_devolucion_estatus` (`id_devolucion_estatus`),
  CONSTRAINT `tc_mantic_devoluciones_bitacora_ibfk_1` FOREIGN KEY (`id_devolucion_estatus`) REFERENCES `tc_mantic_devoluciones_estatus` (`id_devolucion_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_devoluciones_bitacora_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_devoluciones_detalles` */

DROP TABLE IF EXISTS `tc_mantic_devoluciones_detalles`;

CREATE TABLE `tc_mantic_devoluciones_detalles` (
  `id_devolucion_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_devolucion` bigint(11) unsigned NOT NULL,
  `id_nota_detalle` bigint(11) unsigned DEFAULT NULL,
  `cantidad` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_devolucion_detalle`),
  UNIQUE KEY `id_nota_entrada_uk` (`id_devolucion`,`id_nota_detalle`,`cantidad`,`registro`),
  KEY `id_nota_entrada` (`id_devolucion`),
  KEY `id_orden_detalle` (`id_nota_detalle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_devoluciones_estatus` */

DROP TABLE IF EXISTS `tc_mantic_devoluciones_estatus`;

CREATE TABLE `tc_mantic_devoluciones_estatus` (
  `id_devolucion_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_devolucion_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_domicilios` */

DROP TABLE IF EXISTS `tc_mantic_domicilios`;

CREATE TABLE `tc_mantic_domicilios` (
  `id_domicilio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_localidad` bigint(11) unsigned NOT NULL,
  `codigo_postal` varchar(10) COLLATE latin1_bin DEFAULT NULL,
  `calle` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `numero_exterior` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `numero_interior` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `asentamiento` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `entre_calle` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `y_calle` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `latitud` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `longitud` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_domicilio`),
  KEY `id_localidad` (`id_localidad`),
  KEY `codigo_postal` (`codigo_postal`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_domicilios_ibfk_3` FOREIGN KEY (`id_localidad`) REFERENCES `tc_janal_localidades` (`id_localidad`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4542 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_egresos` */

DROP TABLE IF EXISTS `tc_mantic_egresos`;

CREATE TABLE `tc_mantic_egresos` (
  `id_egreso` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `fecha` date NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin NOT NULL,
  `importe` decimal(11,4) DEFAULT '0.0000',
  `id_egreso_estatus` bigint(11) unsigned NOT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_egreso`),
  UNIQUE KEY `fecha` (`fecha`,`descripcion`,`importe`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_egreso_estatus` (`id_egreso_estatus`),
  KEY `id_empresa` (`id_empresa`),
  CONSTRAINT `tc_mantic_egresos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_egresos_ibfk_3` FOREIGN KEY (`id_egreso_estatus`) REFERENCES `tc_mantic_egresos_estatus` (`id_egreso_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_egresos_ibfk_4` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_egresos_archivos` */

DROP TABLE IF EXISTS `tc_mantic_egresos_archivos`;

CREATE TABLE `tc_mantic_egresos_archivos` (
  `id_egreso_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_egreso` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `alias` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `ejercicio` bigint(11) DEFAULT NULL,
  `mes` bigint(11) DEFAULT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '2',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuarios` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_egreso_archivo`),
  UNIQUE KEY `id_egreso_uk` (`id_egreso`,`id_tipo_archivo`,`nombre`),
  KEY `id_egreso` (`id_egreso`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_principal` (`id_principal`),
  KEY `id_usuarios` (`id_usuarios`),
  CONSTRAINT `tc_mantic_egresos_archivos_ibfk_1` FOREIGN KEY (`id_egreso`) REFERENCES `tc_mantic_egresos` (`id_egreso`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_egresos_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_egresos_archivos_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_egresos_archivos_ibfk_4` FOREIGN KEY (`id_usuarios`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_egresos_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_egresos_bitacora`;

CREATE TABLE `tc_mantic_egresos_bitacora` (
  `id_egreso_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_egreso` bigint(11) unsigned NOT NULL,
  `id_egreso_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_egreso_bitacora`),
  KEY `id_egreso` (`id_egreso`),
  KEY `id_egreso_estatus` (`id_egreso_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_egresos_bitacora_ibfk_1` FOREIGN KEY (`id_egreso`) REFERENCES `tc_mantic_egresos` (`id_egreso`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_egresos_bitacora_ibfk_2` FOREIGN KEY (`id_egreso_estatus`) REFERENCES `tc_mantic_egresos_estatus` (`id_egreso_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_egresos_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_egresos_estatus` */

DROP TABLE IF EXISTS `tc_mantic_egresos_estatus`;

CREATE TABLE `tc_mantic_egresos_estatus` (
  `id_egreso_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_egreso_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_egresos_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_egresos_notas` */

DROP TABLE IF EXISTS `tc_mantic_egresos_notas`;

CREATE TABLE `tc_mantic_egresos_notas` (
  `id_egreso_nota` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_egreso` bigint(11) unsigned NOT NULL,
  `comentario` varchar(500) COLLATE latin1_bin NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_egreso_nota`),
  UNIQUE KEY `id_egreso_nota_uk` (`id_egreso`,`comentario`),
  KEY `id_egreso` (`id_egreso`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_egresos_notas_ibfk_1` FOREIGN KEY (`id_egreso`) REFERENCES `tc_mantic_egresos` (`id_egreso`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_egresos_notas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_empaques` */

DROP TABLE IF EXISTS `tc_mantic_empaques`;

CREATE TABLE `tc_mantic_empaques` (
  `id_empaque` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empaque`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_empresas` */

DROP TABLE IF EXISTS `tc_mantic_empresas`;

CREATE TABLE `tc_mantic_empresas` (
  `id_empresa` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_tipo_empresa` bigint(11) unsigned NOT NULL,
  `clave` varchar(50) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `titulo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ticket` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_responsable` bigint(11) unsigned DEFAULT NULL,
  `iva` decimal(11,2) NOT NULL DEFAULT '0.00',
  `id_empresa_depende` bigint(11) unsigned DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_imagen` bigint(11) unsigned DEFAULT NULL,
  `carpeta_trabajo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_usuarios` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empresa`),
  UNIQUE KEY `id_tipos_empresas` (`id_tipo_empresa`,`nombre`),
  KEY `id_tipos_empresas_2` (`id_tipo_empresa`),
  KEY `id_responsable` (`id_responsable`),
  KEY `id_depende_empresa` (`id_empresa_depende`),
  KEY `id_imagen` (`id_imagen`),
  KEY `id_usuarios` (`id_usuarios`),
  CONSTRAINT `tc_mantic_empresas_ibfk_1` FOREIGN KEY (`id_tipo_empresa`) REFERENCES `tc_mantic_tipos_empresas` (`id_tipo_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_ibfk_2` FOREIGN KEY (`id_responsable`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_ibfk_4` FOREIGN KEY (`id_empresa_depende`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_ibfk_5` FOREIGN KEY (`id_imagen`) REFERENCES `tc_mantic_imagenes` (`id_imagen`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_empresas_archivos` */

DROP TABLE IF EXISTS `tc_mantic_empresas_archivos`;

CREATE TABLE `tc_mantic_empresas_archivos` (
  `id_empresa_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa_pago` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `mes` bigint(11) NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empresa_archivo`),
  UNIQUE KEY `id_empresa_pago_uk` (`id_empresa_pago`,`id_tipo_archivo`,`nombre`,`mes`,`ejercicio`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_principal` (`id_principal`),
  KEY `id_empresa_pago` (`id_empresa_pago`),
  CONSTRAINT `tc_mantic_empresas_archivos_ibfk_1` FOREIGN KEY (`id_empresa_pago`) REFERENCES `tc_mantic_empresas_pagos` (`id_empresa_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_archivos_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_archivos_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_empresas_deudas` */

DROP TABLE IF EXISTS `tc_mantic_empresas_deudas`;

CREATE TABLE `tc_mantic_empresas_deudas` (
  `id_empresa_deuda` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_nota_entrada` bigint(11) unsigned NOT NULL,
  `importe` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `pagar` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `saldo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `limite` date NOT NULL,
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_empresa_estatus` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empresa_deuda`),
  UNIQUE KEY `id_empresa_uk` (`id_empresa`,`id_nota_entrada`,`importe`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_nota_entrada` (`id_nota_entrada`),
  KEY `id_empresa_estatus` (`id_empresa_estatus`),
  KEY `registro` (`registro`),
  CONSTRAINT `tc_mantic_empresas_deudas_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_deudas_ibfk_2` FOREIGN KEY (`id_nota_entrada`) REFERENCES `tc_mantic_notas_entradas` (`id_nota_entrada`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_deudas_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_deudas_ibfk_4` FOREIGN KEY (`id_empresa_estatus`) REFERENCES `tc_mantic_empresas_estatus` (`id_empresa_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_empresas_estatus` */

DROP TABLE IF EXISTS `tc_mantic_empresas_estatus`;

CREATE TABLE `tc_mantic_empresas_estatus` (
  `id_empresa_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empresa_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_empresas_pagos` */

DROP TABLE IF EXISTS `tc_mantic_empresas_pagos`;

CREATE TABLE `tc_mantic_empresas_pagos` (
  `id_empresa_pago` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa_deuda` bigint(11) unsigned NOT NULL,
  `id_tipo_medio_pago` bigint(11) unsigned NOT NULL,
  `id_cierre` bigint(11) unsigned DEFAULT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL DEFAULT '201900001',
  `pago` decimal(11,4) DEFAULT '0.0000',
  `id_credito_nota` bigint(11) unsigned DEFAULT NULL,
  `id_nota_entrada` bigint(11) unsigned DEFAULT NULL,
  `id_banco` bigint(11) unsigned DEFAULT NULL,
  `referencia` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_egreso` bigint(11) unsigned DEFAULT NULL,
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ejercicio` bigint(11) unsigned NOT NULL DEFAULT '2019',
  `orden` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empresa_pago`),
  UNIQUE KEY `id_empresa_deuda` (`id_empresa_deuda`,`id_tipo_medio_pago`,`pago`,`registro`),
  KEY `id_empresa_deuda_2` (`id_empresa_deuda`),
  KEY `id_tipo_medio_pago` (`id_tipo_medio_pago`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_credito_nota` (`id_credito_nota`),
  KEY `id_banco` (`id_banco`),
  KEY `id_nota_entrada` (`id_nota_entrada`),
  KEY `id_cierre` (`id_cierre`),
  KEY `id_egreso` (`id_egreso`),
  CONSTRAINT `tc_mantic_empresas_pagos_ibfk_1` FOREIGN KEY (`id_empresa_deuda`) REFERENCES `tc_mantic_empresas_deudas` (`id_empresa_deuda`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_pagos_ibfk_2` FOREIGN KEY (`id_tipo_medio_pago`) REFERENCES `tc_mantic_tipos_medios_pagos` (`id_tipo_medio_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_pagos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_pagos_ibfk_4` FOREIGN KEY (`id_credito_nota`) REFERENCES `tc_mantic_creditos_notas` (`id_credito_nota`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_pagos_ibfk_5` FOREIGN KEY (`id_banco`) REFERENCES `tc_mantic_bancos` (`id_banco`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_pagos_ibfk_6` FOREIGN KEY (`id_nota_entrada`) REFERENCES `tc_mantic_notas_entradas` (`id_nota_entrada`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_pagos_ibfk_7` FOREIGN KEY (`id_cierre`) REFERENCES `tc_mantic_cierres` (`id_cierre`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_empresas_pagos_ibfk_8` FOREIGN KEY (`id_egreso`) REFERENCES `tc_mantic_egresos` (`id_egreso`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_estados_civiles` */

DROP TABLE IF EXISTS `tc_mantic_estados_civiles`;

CREATE TABLE `tc_mantic_estados_civiles` (
  `id_estado_civil` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_estado_civil`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_facturama_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_facturama_bitacora`;

CREATE TABLE `tc_mantic_facturama_bitacora` (
  `id_facturama_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_key` bigint(11) unsigned NOT NULL,
  `proceso` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `codigo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `observacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_facturama_bitacora`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_facturas` */

DROP TABLE IF EXISTS `tc_mantic_facturas`;

CREATE TABLE `tc_mantic_facturas` (
  `id_factura` bigint(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `id_factura_estatus` bigint(11) NOT NULL,
  `folio` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `timbrado` timestamp NULL DEFAULT NULL,
  `intentos` bigint(11) DEFAULT '0',
  `ultimo_intento` date DEFAULT NULL,
  `correos` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `comentarios` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_facturama` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `cadena_original` varchar(6000) COLLATE latin1_bin DEFAULT NULL,
  `sello_sat` varchar(2000) COLLATE latin1_bin DEFAULT NULL,
  `sello_cfdi` varchar(6000) COLLATE latin1_bin DEFAULT NULL,
  `certificado_sat` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `certificado_digital` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `certificacion` timestamp NULL DEFAULT NULL,
  `folio_fiscal` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `cancelada` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_factura`),
  UNIQUE KEY `folio` (`folio`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_facturas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_facturas_archivos` */

DROP TABLE IF EXISTS `tc_mantic_facturas_archivos`;

CREATE TABLE `tc_mantic_facturas_archivos` (
  `id_factura_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_factura` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `mes` bigint(11) NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `comentarios` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `folio_cancelacion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `cancelacion` timestamp NULL DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_factura_archivo`),
  UNIQUE KEY `id_factura_archivo_uk` (`id_factura`,`id_tipo_archivo`,`nombre`,`ejercicio`,`mes`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_nota_entrada` (`id_factura`),
  KEY `id_principal` (`id_principal`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_facturas_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_facturas_bitacora`;

CREATE TABLE `tc_mantic_facturas_bitacora` (
  `id_factura_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_factura` bigint(11) unsigned NOT NULL,
  `id_factura_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registros` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_factura_bitacora`),
  KEY `id_factura` (`id_factura`),
  KEY `id_factura_estatus` (`id_factura_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_facturas_bitacora_ibfk_1` FOREIGN KEY (`id_factura`) REFERENCES `tc_mantic_facturas` (`id_factura`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_facturas_bitacora_ibfk_2` FOREIGN KEY (`id_factura_estatus`) REFERENCES `tc_mantic_facturas_estatus` (`id_factura_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_facturas_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_facturas_estatus` */

DROP TABLE IF EXISTS `tc_mantic_facturas_estatus`;

CREATE TABLE `tc_mantic_facturas_estatus` (
  `id_factura_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(500) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_factura_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_facturas_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_faltantes` */

DROP TABLE IF EXISTS `tc_mantic_faltantes`;

CREATE TABLE `tc_mantic_faltantes` (
  `id_faltante` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `cantidad` decimal(11,2) NOT NULL DEFAULT '0.00',
  `id_vigente` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `actualizado` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_faltante`),
  UNIQUE KEY `id_articulo_uk` (`id_articulo`,`cantidad`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_vigente` (`id_vigente`),
  KEY `id_empresa` (`id_empresa`),
  CONSTRAINT `tc_mantic_faltantes_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_faltantes_ibfk_2` FOREIGN KEY (`id_vigente`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_faltantes_ibfk_3` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ficticias` */

DROP TABLE IF EXISTS `tc_mantic_ficticias`;

CREATE TABLE `tc_mantic_ficticias` (
  `id_ficticia` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `extras` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `sub_total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `tipo_de_cambio` decimal(11,4) DEFAULT '0.0000',
  `dia` date NOT NULL,
  `id_ficticia_estatus` bigint(11) unsigned NOT NULL,
  `id_sin_iva` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_uso_cfdi` bigint(11) unsigned DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `global` decimal(11,4) DEFAULT '0.0000',
  `id_cliente` bigint(11) unsigned NOT NULL,
  `id_cliente_domicilio` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_tipo_medio_pago` bigint(11) unsigned NOT NULL,
  `id_tipo_pago` bigint(11) unsigned NOT NULL,
  `id_banco` bigint(11) unsigned DEFAULT NULL,
  `referencia` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_factura` bigint(11) unsigned DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ficticia`),
  UNIQUE KEY `consecutivo` (`consecutivo`,`dia`,`id_empresa`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_sin_iva` (`id_sin_iva`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_uso_cfdi` (`id_uso_cfdi`),
  KEY `id_ficticia_estatus` (`id_ficticia_estatus`),
  KEY `id_tipo_medio_pago` (`id_tipo_medio_pago`),
  KEY `id_tipo_pago` (`id_tipo_pago`),
  KEY `id_banco` (`id_banco`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_cliente_domicilio` (`id_cliente_domicilio`),
  KEY `id_factura` (`id_factura`),
  CONSTRAINT `tc_mantic_ficticias_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ficticias_ibfk_10` FOREIGN KEY (`id_cliente_domicilio`) REFERENCES `tr_mantic_cliente_domicilio` (`id_cliente_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ficticias_ibfk_2` FOREIGN KEY (`id_sin_iva`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ficticias_ibfk_4` FOREIGN KEY (`id_uso_cfdi`) REFERENCES `tc_mantic_usos_cfdi` (`id_uso_cfdi`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ficticias_ibfk_5` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ficticias_ibfk_6` FOREIGN KEY (`id_ficticia_estatus`) REFERENCES `tc_mantic_ficticias_estatus` (`id_ficticia_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ficticias_ibfk_7` FOREIGN KEY (`id_tipo_medio_pago`) REFERENCES `tc_mantic_tipos_medios_pagos` (`id_tipo_medio_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ficticias_ibfk_8` FOREIGN KEY (`id_tipo_pago`) REFERENCES `tc_mantic_tipos_pagos` (`id_tipo_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ficticias_ibfk_9` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ficticias_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_ficticias_bitacora`;

CREATE TABLE `tc_mantic_ficticias_bitacora` (
  `id_ficticia_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_ficticia` bigint(11) unsigned NOT NULL,
  `id_ficticia_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `importe` decimal(11,2) NOT NULL DEFAULT '0.00',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ficticia_bitacora`),
  UNIQUE KEY `id_garantia_uk` (`id_ficticia`,`id_ficticia_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_garantia` (`id_ficticia`),
  KEY `id_garantia_estatus` (`id_ficticia_estatus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ficticias_detalles` */

DROP TABLE IF EXISTS `tc_mantic_ficticias_detalles`;

CREATE TABLE `tc_mantic_ficticias_detalles` (
  `id_ficticia_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_ficticia` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned DEFAULT NULL,
  `codigo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `sat` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `cantidad` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `precio` decimal(11,4) DEFAULT '0.0000',
  `costo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `extras` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `iva` decimal(11,4) DEFAULT '16.0000',
  `impuestos` decimal(11,4) DEFAULT '0.0000',
  `sub_total` decimal(11,4) DEFAULT '0.0000',
  `importe` decimal(11,4) DEFAULT '0.0000',
  `unidad_medida` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `utilidad` decimal(11,4) DEFAULT '0.0000',
  `unitario_sin_iva` decimal(11,4) DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ficticia_detalle`),
  UNIQUE KEY `id_ficticia_articulo` (`id_ficticia`,`id_articulo`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_ficticia` (`id_ficticia`),
  CONSTRAINT `tc_mantic_ficticias_detalles_ibfk_1` FOREIGN KEY (`id_ficticia`) REFERENCES `tc_mantic_ficticias` (`id_ficticia`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ficticias_detalles_ibfk_2` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ficticias_estatus` */

DROP TABLE IF EXISTS `tc_mantic_ficticias_estatus`;

CREATE TABLE `tc_mantic_ficticias_estatus` (
  `id_ficticia_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ficticia_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_garantias` */

DROP TABLE IF EXISTS `tc_mantic_garantias`;

CREATE TABLE `tc_mantic_garantias` (
  `id_garantia` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_venta` bigint(11) unsigned NOT NULL,
  `consecutivo` bigint(11) NOT NULL,
  `descuentos` decimal(11,2) DEFAULT '0.00',
  `impuestos` decimal(11,2) NOT NULL DEFAULT '0.00',
  `sub_total` decimal(11,2) NOT NULL DEFAULT '0.00',
  `total` decimal(11,2) NOT NULL DEFAULT '0.00',
  `id_garantia_estatus` bigint(11) unsigned NOT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `utilidad` decimal(11,2) DEFAULT '0.00',
  `id_efectivo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_garantia`),
  UNIQUE KEY `consecutivo` (`consecutivo`,`id_venta`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_garantia_estatus` (`id_garantia_estatus`),
  KEY `id_venta` (`id_venta`),
  KEY `id_efectivo` (`id_efectivo`),
  CONSTRAINT `tc_mantic_garantias_ibfk_1` FOREIGN KEY (`id_venta`) REFERENCES `tc_mantic_ventas` (`id_venta`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_garantias_ibfk_2` FOREIGN KEY (`id_garantia_estatus`) REFERENCES `tc_mantic_garantias_estatus` (`id_garantia_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_garantias_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_garantias_ibfk_5` FOREIGN KEY (`id_efectivo`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_garantias_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_garantias_bitacora`;

CREATE TABLE `tc_mantic_garantias_bitacora` (
  `id_garantia_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_garantia` bigint(11) unsigned NOT NULL,
  `id_garantia_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `consecutivo` bigint(11) NOT NULL DEFAULT '0',
  `importe` decimal(11,2) NOT NULL DEFAULT '0.00',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_garantia_bitacora`),
  UNIQUE KEY `id_garantia_uk` (`id_garantia`,`id_garantia_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_garantia` (`id_garantia`),
  KEY `id_garantia_estatus` (`id_garantia_estatus`),
  CONSTRAINT `tc_mantic_garantias_bitacora_ibfk_1` FOREIGN KEY (`id_garantia`) REFERENCES `tc_mantic_garantias` (`id_garantia`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_garantias_bitacora_ibfk_2` FOREIGN KEY (`id_garantia_estatus`) REFERENCES `tc_mantic_garantias_estatus` (`id_garantia_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_garantias_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_garantias_detalles` */

DROP TABLE IF EXISTS `tc_mantic_garantias_detalles`;

CREATE TABLE `tc_mantic_garantias_detalles` (
  `id_garantia_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_garantia` bigint(11) unsigned NOT NULL,
  `id_venta_detalle` bigint(11) unsigned DEFAULT NULL,
  `cantidad` decimal(11,2) NOT NULL DEFAULT '0.00',
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `extras` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `descuentos` decimal(11,2) DEFAULT '0.00',
  `iva` decimal(11,2) DEFAULT '16.00',
  `impuestos` decimal(11,2) DEFAULT '0.00',
  `sub_total` decimal(11,2) DEFAULT '0.00',
  `importe` decimal(11,2) DEFAULT '0.00',
  `utilidad` decimal(11,2) DEFAULT '0.00',
  `id_reparacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_proveedor` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_garantia_detalle`),
  UNIQUE KEY `id_garantia_uk` (`id_garantia`,`id_venta_detalle`),
  KEY `id_venta_detale` (`id_venta_detalle`),
  KEY `id_garantia` (`id_garantia`),
  KEY `id_reparacion` (`id_reparacion`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `tc_mantic_garantias_detalles_ibfk_1` FOREIGN KEY (`id_garantia`) REFERENCES `tc_mantic_garantias` (`id_garantia`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_garantias_detalles_ibfk_2` FOREIGN KEY (`id_venta_detalle`) REFERENCES `tc_mantic_ventas_detalles` (`id_venta_detalle`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_garantias_detalles_ibfk_3` FOREIGN KEY (`id_reparacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_garantias_detalles_ibfk_4` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_garantias_estatus` */

DROP TABLE IF EXISTS `tc_mantic_garantias_estatus`;

CREATE TABLE `tc_mantic_garantias_estatus` (
  `id_garantia_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_garantia_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_grupos` */

DROP TABLE IF EXISTS `tc_mantic_grupos`;

CREATE TABLE `tc_mantic_grupos` (
  `id_grupo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_grupo`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_grupos_clientes` */

DROP TABLE IF EXISTS `tc_mantic_grupos_clientes`;

CREATE TABLE `tc_mantic_grupos_clientes` (
  `id_grupo_cliente` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_grupo` bigint(11) unsigned NOT NULL,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_grupo_cliente`),
  UNIQUE KEY `id_grupo` (`id_grupo`,`id_cliente`),
  KEY `id_grupo_2` (`id_grupo`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `tc_mantic_grupos_clientes_ibfk_1` FOREIGN KEY (`id_grupo`) REFERENCES `tc_mantic_grupos` (`id_grupo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_grupos_clientes_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_historial_iva` */

DROP TABLE IF EXISTS `tc_mantic_historial_iva`;

CREATE TABLE `tc_mantic_historial_iva` (
  `id_historial_iva` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `importe` decimal(11,2) NOT NULL DEFAULT '0.00',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_historial_iva`),
  UNIQUE KEY `id_empresa` (`id_empresa`,`importe`,`registro`),
  KEY `id_empresa_2` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_historial_iva_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_imagenes` */

DROP TABLE IF EXISTS `tc_mantic_imagenes`;

CREATE TABLE `tc_mantic_imagenes` (
  `id_imagen` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(255) COLLATE latin1_bin NOT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_tipo_imagen` bigint(11) unsigned NOT NULL,
  `tamanio` bigint(11) DEFAULT '0',
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_imagen`),
  UNIQUE KEY `nombre` (`nombre`,`id_tipo_imagen`),
  KEY `id_tipo_imagen` (`id_tipo_imagen`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_imagenes_ibfk_1` FOREIGN KEY (`id_tipo_imagen`) REFERENCES `tc_mantic_tipos_imagenes` (`id_tipo_imagen`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_incidentes` */

DROP TABLE IF EXISTS `tc_mantic_incidentes`;

CREATE TABLE `tc_mantic_incidentes` (
  `id_incidente` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `id_persona` bigint(11) unsigned NOT NULL,
  `id_tipo_incidente` bigint(11) unsigned NOT NULL,
  `vigencia_inicio` date DEFAULT NULL,
  `vigencia_fin` date DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `id_incidente_estatus` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_incidente`),
  UNIQUE KEY `consecutivo_uk` (`consecutivo`),
  KEY `id_persona` (`id_persona`),
  KEY `id_tipo_incidente` (`id_tipo_incidente`),
  KEY `id_incidente_estatus` (`id_incidente_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_incidentes_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_incidentes_ibfk_2` FOREIGN KEY (`id_tipo_incidente`) REFERENCES `tc_mantic_tipos_incidentes` (`id_tipo_incidente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_incidentes_ibfk_3` FOREIGN KEY (`id_incidente_estatus`) REFERENCES `tc_mantic_incidentes_estatus` (`id_incidente_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_incidentes_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_incidentes_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_incidentes_bitacora`;

CREATE TABLE `tc_mantic_incidentes_bitacora` (
  `id_incidente_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_incidente` bigint(11) unsigned NOT NULL,
  `id_incidente_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_incidente_bitacora`),
  UNIQUE KEY `bitacora_uk` (`id_incidente`,`id_incidente_estatus`,`registro`),
  KEY `id_incidente` (`id_incidente`),
  KEY `id_incidente_estatus` (`id_incidente_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_incidentes_bitacora_ibfk_1` FOREIGN KEY (`id_incidente`) REFERENCES `tc_mantic_incidentes` (`id_incidente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_incidentes_bitacora_ibfk_2` FOREIGN KEY (`id_incidente_estatus`) REFERENCES `tc_mantic_incidentes_estatus` (`id_incidente_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_incidentes_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_incidentes_estatus` */

DROP TABLE IF EXISTS `tc_mantic_incidentes_estatus`;

CREATE TABLE `tc_mantic_incidentes_estatus` (
  `id_incidente_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_incidente_estatus`),
  UNIQUE KEY `nombre_uk` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_incidentes_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_inventarios` */

DROP TABLE IF EXISTS `tc_mantic_inventarios`;

CREATE TABLE `tc_mantic_inventarios` (
  `id_inventario` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_almacen` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `ejercicio` bigint(11) DEFAULT NULL,
  `inicial` decimal(11,2) DEFAULT '0.00',
  `entradas` decimal(11,2) DEFAULT '0.00',
  `salidas` decimal(11,2) DEFAULT '0.00',
  `stock` decimal(11,2) NOT NULL DEFAULT '0.00',
  `id_automatico` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_inventario`),
  UNIQUE KEY `id_almacen_uk` (`id_almacen`,`id_articulo`,`ejercicio`,`registro`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_almacen` (`id_almacen`),
  KEY `id_automatico` (`id_automatico`),
  CONSTRAINT `tc_mantic_inventarios_ibfk_1` FOREIGN KEY (`id_almacen`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_inventarios_ibfk_2` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_inventarios_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_inventarios_ibfk_4` FOREIGN KEY (`id_automatico`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_listas_precios` */

DROP TABLE IF EXISTS `tc_mantic_listas_precios`;

CREATE TABLE `tc_mantic_listas_precios` (
  `id_lista_precio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_proveedor` bigint(11) unsigned DEFAULT NULL,
  `nombre` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `logotipo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_lista_precio`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  CONSTRAINT `tc_mantic_listas_precios_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_listas_precios_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_listas_precios_ibfk_3` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_listas_precios_archivos` */

DROP TABLE IF EXISTS `tc_mantic_listas_precios_archivos`;

CREATE TABLE `tc_mantic_listas_precios_archivos` (
  `id_lista_precio_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_lista_precio` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_lista_precio_archivo`),
  UNIQUE KEY `id_lista_precio_uk` (`id_lista_precio`,`id_tipo_archivo`,`nombre`,`ruta`,`registro`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_lista_precio` (`id_lista_precio`),
  KEY `id_principal` (`id_principal`),
  CONSTRAINT `tc_mantic_listas_precios_archivos_ibfk_1` FOREIGN KEY (`id_lista_precio`) REFERENCES `tc_mantic_listas_precios` (`id_lista_precio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_listas_precios_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_listas_precios_archivos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_listas_precios_archivos_ibfk_4` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_listas_precios_detalles` */

DROP TABLE IF EXISTS `tc_mantic_listas_precios_detalles`;

CREATE TABLE `tc_mantic_listas_precios_detalles` (
  `id_lista_precio_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_lista_precio` bigint(11) unsigned NOT NULL,
  `codigo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `auxiliar` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `costo` decimal(11,4) DEFAULT '0.0000',
  `precio` decimal(11,4) DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_lista_precio_detalle`),
  KEY `id_lista_precio` (`id_lista_precio`),
  CONSTRAINT `tc_mantic_listas_precios_detalles_ibfk_1` FOREIGN KEY (`id_lista_precio`) REFERENCES `tc_mantic_listas_precios` (`id_lista_precio`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_marcas` */

DROP TABLE IF EXISTS `tc_mantic_marcas`;

CREATE TABLE `tc_mantic_marcas` (
  `id_marca` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_marca`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_masivas_archivos` */

DROP TABLE IF EXISTS `tc_mantic_masivas_archivos`;

CREATE TABLE `tc_mantic_masivas_archivos` (
  `id_masiva_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_tipo_masivo` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tuplas` bigint(11) unsigned DEFAULT '0',
  `tamanio` bigint(11) DEFAULT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_masiva_estatus` bigint(11) unsigned NOT NULL DEFAULT '2',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_masiva_archivo`),
  UNIQUE KEY `id_masiva_uk` (`id_tipo_masivo`,`id_tipo_archivo`,`nombre`,`ruta`,`registro`,`id_empresa`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_lista_precio` (`id_tipo_masivo`),
  KEY `id_masiva_estatus` (`id_masiva_estatus`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_principal` (`id_principal`),
  CONSTRAINT `tc_mantic_masivas_archivos_ibfk_1` FOREIGN KEY (`id_tipo_masivo`) REFERENCES `tc_mantic_tipos_masivos` (`id_tipo_masivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_masivas_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_masivas_archivos_ibfk_3` FOREIGN KEY (`id_masiva_estatus`) REFERENCES `tc_mantic_masivas_estatus` (`id_masiva_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_masivas_archivos_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_masivas_archivos_ibfk_5` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_masivas_archivos_ibfk_6` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_masivas_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_masivas_bitacora`;

CREATE TABLE `tc_mantic_masivas_bitacora` (
  `id_masiva_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_masiva_archivo` bigint(11) unsigned NOT NULL,
  `id_masiva_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `procesados` bigint(11) NOT NULL DEFAULT '0',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_masiva_bitacora`),
  UNIQUE KEY `id_masiva_uk` (`id_masiva_archivo`,`id_masiva_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_masiva_archivos` (`id_masiva_archivo`),
  KEY `id_masiva_estatus` (`id_masiva_estatus`),
  CONSTRAINT `tc_mantic_masivas_bitacora_ibfk_1` FOREIGN KEY (`id_masiva_archivo`) REFERENCES `tc_mantic_masivas_archivos` (`id_masiva_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_masivas_bitacora_ibfk_2` FOREIGN KEY (`id_masiva_estatus`) REFERENCES `tc_mantic_masivas_estatus` (`id_masiva_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_masivas_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_masivas_detalles` */

DROP TABLE IF EXISTS `tc_mantic_masivas_detalles`;

CREATE TABLE `tc_mantic_masivas_detalles` (
  `id_masiva_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_masiva_archivo` bigint(11) unsigned NOT NULL,
  `codigo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_masiva_detalle`),
  UNIQUE KEY `id_masiva_archivo` (`id_masiva_archivo`,`codigo`,`registro`),
  KEY `id_masiva_archivo_2` (`id_masiva_archivo`),
  CONSTRAINT `tc_mantic_masivas_detalles_ibfk_1` FOREIGN KEY (`id_masiva_archivo`) REFERENCES `tc_mantic_masivas_archivos` (`id_masiva_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_masivas_estatus` */

DROP TABLE IF EXISTS `tc_mantic_masivas_estatus`;

CREATE TABLE `tc_mantic_masivas_estatus` (
  `id_masiva_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_masiva_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_masivas_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_monedas` */

DROP TABLE IF EXISTS `tc_mantic_monedas`;

CREATE TABLE `tc_mantic_monedas` (
  `id_moneda` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `denominacion` decimal(11,2) NOT NULL,
  `nombre` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `orden` bigint(11) DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_moneda`),
  UNIQUE KEY `denominacion` (`denominacion`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_movimientos` */

DROP TABLE IF EXISTS `tc_mantic_movimientos`;

CREATE TABLE `tc_mantic_movimientos` (
  `id_movimiento` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_tipo_movimiento` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_almacen` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `cantidad` decimal(11,2) NOT NULL DEFAULT '0.00',
  `stock` decimal(11,2) NOT NULL DEFAULT '0.00',
  `calculo` decimal(11,2) NOT NULL DEFAULT '0.00',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_movimiento`),
  KEY `id_tipo_movimiento` (`id_tipo_movimiento`),
  KEY `id_almacen` (`id_almacen`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_movimientos_ibfk_1` FOREIGN KEY (`id_tipo_movimiento`) REFERENCES `tc_mantic_tipos_movimientos` (`id_tipo_movimiento`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_movimientos_ibfk_2` FOREIGN KEY (`id_almacen`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_movimientos_ibfk_3` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_movimientos_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_notas_archivos` */

DROP TABLE IF EXISTS `tc_mantic_notas_archivos`;

CREATE TABLE `tc_mantic_notas_archivos` (
  `id_nota_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_nota_entrada` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `archivo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `mes` bigint(11) NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nota_archivo`),
  UNIQUE KEY `id_nota_entrada_uk` (`id_nota_entrada`,`id_tipo_archivo`,`nombre`,`ejercicio`,`mes`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_nota_entrada` (`id_nota_entrada`),
  KEY `id_principal` (`id_principal`),
  CONSTRAINT `tc_mantic_notas_archivos_ibfk_1` FOREIGN KEY (`id_nota_entrada`) REFERENCES `tc_mantic_notas_entradas` (`id_nota_entrada`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_archivos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_archivos_ibfk_4` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_notas_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_notas_bitacora`;

CREATE TABLE `tc_mantic_notas_bitacora` (
  `id_nota_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_nota_entrada` bigint(11) unsigned NOT NULL,
  `id_nota_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `importe` decimal(11,2) NOT NULL DEFAULT '0.00',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nota_bitacora`),
  UNIQUE KEY `id_nota_entrada_uk` (`id_nota_entrada`,`id_nota_estatus`,`registro`),
  KEY `id_nota_entrada` (`id_nota_entrada`),
  KEY `id_nota_estatus` (`id_nota_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_notas_bitacora_ibfk_2` FOREIGN KEY (`id_nota_estatus`) REFERENCES `tc_mantic_notas_estatus` (`id_nota_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_notas_creditos` */

DROP TABLE IF EXISTS `tc_mantic_notas_creditos`;

CREATE TABLE `tc_mantic_notas_creditos` (
  `id_nota_credito` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_devolucion` bigint(11) unsigned NOT NULL,
  `folio` varchar(255) COLLATE latin1_bin NOT NULL,
  `importe` decimal(11,2) NOT NULL DEFAULT '0.00',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nota_credito`),
  UNIQUE KEY `id_devolucion_uk` (`id_devolucion`,`folio`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_devolucion` (`id_devolucion`),
  CONSTRAINT `tc_mantic_notas_creditos_ibfk_1` FOREIGN KEY (`id_devolucion`) REFERENCES `tc_mantic_devoluciones` (`id_devolucion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_creditos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_notas_detalles` */

DROP TABLE IF EXISTS `tc_mantic_notas_detalles`;

CREATE TABLE `tc_mantic_notas_detalles` (
  `id_nota_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_nota_entrada` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned DEFAULT NULL,
  `codigo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `sat` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `cantidad` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `costo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `extras` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `iva` decimal(11,4) DEFAULT '16.0000',
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `excedentes` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) DEFAULT '0.0000',
  `sub_total` decimal(11,4) DEFAULT '0.0000',
  `importe` decimal(11,4) DEFAULT '0.0000',
  `unidad_medida` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_orden_detalle` bigint(11) unsigned DEFAULT NULL,
  `id_aplicar` bigint(11) unsigned NOT NULL DEFAULT '1',
  `cantidades` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `declarados` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `diferencia` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `costo_real` decimal(11,4) DEFAULT '0.0000',
  `costo_calculado` decimal(11,4) DEFAULT '0.0000',
  `origen` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nota_detalle`),
  UNIQUE KEY `id_nota_entrada_uk` (`id_nota_entrada`,`id_articulo`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_nota_entrada` (`id_nota_entrada`),
  KEY `id_orden_detalle` (`id_orden_detalle`),
  KEY `id_aplicar` (`id_aplicar`),
  CONSTRAINT `tc_mantic_notas_detalles_ibfk_1` FOREIGN KEY (`id_nota_entrada`) REFERENCES `tc_mantic_notas_entradas` (`id_nota_entrada`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_detalles_ibfk_2` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_detalles_ibfk_3` FOREIGN KEY (`id_orden_detalle`) REFERENCES `tc_mantic_ordenes_detalles` (`id_orden_detalle`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_detalles_ibfk_4` FOREIGN KEY (`id_aplicar`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_notas_entradas` */

DROP TABLE IF EXISTS `tc_mantic_notas_entradas`;

CREATE TABLE `tc_mantic_notas_entradas` (
  `id_nota_entrada` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_orden_compra` bigint(11) unsigned DEFAULT NULL,
  `id_almacen` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_proveedor` bigint(11) unsigned DEFAULT NULL,
  `id_proveedor_pago` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `factura` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `original` decimal(11,4) DEFAULT '0.0000',
  `fecha_factura` date DEFAULT NULL,
  `fecha_recepcion` date DEFAULT NULL,
  `sub_total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `descuento` varchar(100) COLLATE latin1_bin NOT NULL,
  `extras` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `excedentes` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `tipo_de_cambio` decimal(11,4) DEFAULT '0.0000',
  `id_sin_iva` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_nota_estatus` bigint(11) unsigned DEFAULT NULL,
  `id_nota_tipo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `dias_plazo` bigint(11) NOT NULL DEFAULT '30',
  `fecha_pago` date NOT NULL,
  `deuda` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nota_entrada`),
  UNIQUE KEY `id_empresa_uk` (`id_empresa`,`id_orden_compra`,`ejercicio`,`orden`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_nota_estatus` (`id_nota_estatus`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_orden_compra` (`id_orden_compra`),
  KEY `id_almacen` (`id_almacen`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_sin_iva` (`id_sin_iva`),
  KEY `id_nota_tipo` (`id_nota_tipo`),
  KEY `id_proveedor_pago` (`id_proveedor_pago`),
  CONSTRAINT `tc_mantic_notas_entradas_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_entradas_ibfk_10` FOREIGN KEY (`id_nota_tipo`) REFERENCES `tc_mantic_notas_tipos` (`id_nota_tipo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_entradas_ibfk_11` FOREIGN KEY (`id_proveedor_pago`) REFERENCES `tr_mantic_proveedor_pago` (`id_proveedor_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_entradas_ibfk_2` FOREIGN KEY (`id_nota_estatus`) REFERENCES `tc_mantic_notas_estatus` (`id_nota_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_entradas_ibfk_4` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_entradas_ibfk_6` FOREIGN KEY (`id_almacen`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_entradas_ibfk_8` FOREIGN KEY (`id_sin_iva`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_notas_entradas_ibfk_9` FOREIGN KEY (`id_orden_compra`) REFERENCES `tc_mantic_ordenes_compras` (`id_orden_compra`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_notas_estatus` */

DROP TABLE IF EXISTS `tc_mantic_notas_estatus`;

CREATE TABLE `tc_mantic_notas_estatus` (
  `id_nota_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nota_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_notas_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_notas_tipos` */

DROP TABLE IF EXISTS `tc_mantic_notas_tipos`;

CREATE TABLE `tc_mantic_notas_tipos` (
  `id_nota_tipo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nota_tipo`),
  UNIQUE KEY `descripcion` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ordenes_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_ordenes_bitacora`;

CREATE TABLE `tc_mantic_ordenes_bitacora` (
  `id_orden_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_orden_compra` bigint(11) unsigned NOT NULL,
  `id_orden_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `importe` decimal(11,2) NOT NULL DEFAULT '0.00',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_orden_bitacora`),
  UNIQUE KEY `id_orden_compra_2` (`id_orden_compra`,`id_orden_estatus`,`registro`),
  KEY `id_orden_compra` (`id_orden_compra`),
  KEY `id_orden_estatus` (`id_orden_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_ordenes_bitacora_ibfk_2` FOREIGN KEY (`id_orden_estatus`) REFERENCES `tc_mantic_ordenes_estatus` (`id_orden_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ordenes_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ordenes_compras` */

DROP TABLE IF EXISTS `tc_mantic_ordenes_compras`;

CREATE TABLE `tc_mantic_ordenes_compras` (
  `id_orden_compra` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `consecutivo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `id_proveedor_pago` bigint(11) unsigned DEFAULT NULL,
  `id_almacen` bigint(11) unsigned NOT NULL,
  `id_cliente` bigint(11) unsigned DEFAULT NULL,
  `entrega_estimada` date NOT NULL,
  `tipo_de_cambio` decimal(11,4) DEFAULT '1.0000',
  `descuento` varchar(100) COLLATE latin1_bin NOT NULL,
  `extras` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `impuestos` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `excedentes` decimal(11,4) DEFAULT '0.0000',
  `sub_total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `id_gasto` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_orden_estatus` bigint(11) unsigned NOT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `id_sin_iva` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_orden_compra`),
  UNIQUE KEY `id_empresa_uk` (`id_empresa`,`ejercicio`,`orden`),
  KEY `id_proveedor_pago` (`id_proveedor_pago`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_gasto` (`id_gasto`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_almacen` (`id_almacen`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_sin_iva` (`id_sin_iva`),
  KEY `id_orden_estatus` (`id_orden_estatus`),
  KEY `id_empresa` (`id_empresa`),
  CONSTRAINT `tc_mantic_ordenes_compras_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ordenes_compras_ibfk_10` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ordenes_compras_ibfk_12` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ordenes_compras_ibfk_13` FOREIGN KEY (`id_sin_iva`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ordenes_compras_ibfk_14` FOREIGN KEY (`id_orden_estatus`) REFERENCES `tc_mantic_ordenes_estatus` (`id_orden_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ordenes_compras_ibfk_5` FOREIGN KEY (`id_proveedor_pago`) REFERENCES `tr_mantic_proveedor_pago` (`id_proveedor_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ordenes_compras_ibfk_8` FOREIGN KEY (`id_gasto`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ordenes_compras_ibfk_9` FOREIGN KEY (`id_almacen`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ordenes_detalles` */

DROP TABLE IF EXISTS `tc_mantic_ordenes_detalles`;

CREATE TABLE `tc_mantic_ordenes_detalles` (
  `id_orden_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_orden_compra` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `codigo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `propio` varchar(255) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(500) COLLATE latin1_bin NOT NULL,
  `cantidad` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `costo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `descuento` varchar(100) COLLATE latin1_bin NOT NULL,
  `extras` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `iva` decimal(11,4) DEFAULT '0.0000',
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `excedentes` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) DEFAULT '0.0000',
  `sub_total` decimal(11,4) DEFAULT '0.0000',
  `importe` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `cantidades` decimal(11,4) DEFAULT '0.0000',
  `precios` decimal(11,4) DEFAULT '0.0000',
  `importes` decimal(11,4) DEFAULT '0.0000',
  `costo_real` decimal(11,4) DEFAULT '0.0000',
  `costo_calculado` decimal(11,4) DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_orden_detalle`),
  UNIQUE KEY `id_orden_compra` (`id_orden_compra`,`id_articulo`),
  KEY `id_orden_compra_2` (`id_orden_compra`),
  KEY `id_articulo` (`id_articulo`),
  CONSTRAINT `tc_mantic_ordenes_detalles_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ordenes_detalles_ibfk_2` FOREIGN KEY (`id_orden_compra`) REFERENCES `tc_mantic_ordenes_compras` (`id_orden_compra`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ordenes_estatus` */

DROP TABLE IF EXISTS `tc_mantic_ordenes_estatus`;

CREATE TABLE `tc_mantic_ordenes_estatus` (
  `id_orden_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_orden_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_ordenes_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_pedidos` */

DROP TABLE IF EXISTS `tc_mantic_pedidos`;

CREATE TABLE `tc_mantic_pedidos` (
  `id_pedido` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `ejercicio` bigint(11) DEFAULT NULL,
  `orden` bigint(11) DEFAULT '1',
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `extras` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `excedentes` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) DEFAULT '0.0000',
  `sub_total` decimal(11,4) DEFAULT '0.0000',
  `total` decimal(11,4) DEFAULT '0.0000',
  `id_pedido_estatus` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pedido`),
  UNIQUE KEY `id_empresa` (`id_empresa`,`id_usuario`,`ejercicio`,`orden`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_pedido_estatus` (`id_pedido_estatus`),
  CONSTRAINT `tc_mantic_pedidos_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_pedidos_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_pedidos_ibfk_3` FOREIGN KEY (`id_pedido_estatus`) REFERENCES `tc_mantic_pedidos_estatus` (`id_pedido_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_pedidos_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_pedidos_bitacora`;

CREATE TABLE `tc_mantic_pedidos_bitacora` (
  `id_pedido_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido` bigint(11) unsigned NOT NULL,
  `id_pedido_estatus` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pedido_bitacora`),
  UNIQUE KEY `id_pedido` (`id_pedido`,`id_pedido_estatus`,`registro`),
  KEY `id_pedido_estatus` (`id_pedido_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_pedidos_bitacora_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `tc_mantic_pedidos` (`id_pedido`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_pedidos_bitacora_ibfk_2` FOREIGN KEY (`id_pedido_estatus`) REFERENCES `tc_mantic_pedidos_estatus` (`id_pedido_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_pedidos_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_pedidos_detalles` */

DROP TABLE IF EXISTS `tc_mantic_pedidos_detalles`;

CREATE TABLE `tc_mantic_pedidos_detalles` (
  `id_pedido_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `codigo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `sat` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `cantidad` decimal(11,4) DEFAULT '0.0000',
  `precio` decimal(11,4) DEFAULT '0.0000',
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `extra` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `iva` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) DEFAULT '0.0000',
  `sub_total` decimal(11,4) DEFAULT '0.0000',
  `importe` decimal(11,4) DEFAULT '0.0000',
  `unidad_medida` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `unitario_sin_iva` decimal(11,4) DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pedido_detalle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_pedidos_estatus` */

DROP TABLE IF EXISTS `tc_mantic_pedidos_estatus`;

CREATE TABLE `tc_mantic_pedidos_estatus` (
  `id_pedido_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociado` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pedido_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_pedidos_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_persona_domicilio` */

DROP TABLE IF EXISTS `tc_mantic_persona_domicilio`;

CREATE TABLE `tc_mantic_persona_domicilio` (
  `id_persona_domicilio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(11) unsigned NOT NULL,
  `id_domicilio` bigint(11) unsigned NOT NULL,
  `id_tipo_domicilio` bigint(11) unsigned NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '2',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_persona_domicilio`),
  UNIQUE KEY `id_persona` (`id_persona`,`id_domicilio`,`id_tipo_domicilio`,`id_principal`),
  KEY `id_persona_2` (`id_persona`),
  KEY `id_domicilio` (`id_domicilio`),
  KEY `id_tipo_domicilio` (`id_tipo_domicilio`),
  KEY `id_principal` (`id_principal`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_personas` */

DROP TABLE IF EXISTS `tc_mantic_personas`;

CREATE TABLE `tc_mantic_personas` (
  `id_persona` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_persona_titulo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `nombres` varchar(100) COLLATE latin1_bin NOT NULL,
  `paterno` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `materno` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `rfc` varchar(13) COLLATE latin1_bin DEFAULT NULL,
  `curp` varchar(18) COLLATE latin1_bin DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `id_tipo_persona` bigint(11) unsigned NOT NULL,
  `id_tipo_sexo` bigint(11) unsigned NOT NULL,
  `estilo` varchar(100) COLLATE latin1_bin NOT NULL DEFAULT 'sentinel',
  `cuenta` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `contrasenia` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `id_lugar_nacimiento` bigint(11) unsigned NOT NULL DEFAULT '1',
  `sueldo` decimal(11,2) DEFAULT NULL,
  `id_estado_civil` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_persona`),
  UNIQUE KEY `rcf` (`registro`),
  UNIQUE KEY `cuenta` (`cuenta`),
  KEY `id_tipo_persona` (`id_tipo_persona`),
  KEY `id_tipo_sexo` (`id_tipo_sexo`),
  KEY `id_persona_titulo` (`id_persona_titulo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_estado_civil` (`id_estado_civil`),
  KEY `id_lugar_nacimiento` (`id_lugar_nacimiento`),
  CONSTRAINT `tc_mantic_personas_ibfk_2` FOREIGN KEY (`id_persona_titulo`) REFERENCES `tc_mantic_personas_titulos` (`id_persona_titulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_personas_ibfk_3` FOREIGN KEY (`id_tipo_persona`) REFERENCES `tc_mantic_tipos_personas` (`id_tipo_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_personas_ibfk_4` FOREIGN KEY (`id_tipo_sexo`) REFERENCES `tc_janal_tipos_sexos` (`id_tipo_sexo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_personas_ibfk_5` FOREIGN KEY (`id_estado_civil`) REFERENCES `tc_mantic_estados_civiles` (`id_estado_civil`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_personas_ibfk_6` FOREIGN KEY (`id_lugar_nacimiento`) REFERENCES `tc_janal_entidades` (`id_entidad`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_personas_archivos` */

DROP TABLE IF EXISTS `tc_mantic_personas_archivos`;

CREATE TABLE `tc_mantic_personas_archivos` (
  `id_persona_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(11) unsigned NOT NULL,
  `id_tipo_archivo` bigint(11) unsigned NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_persona_archivo`),
  UNIQUE KEY `id_persona_archivo_uk` (`id_persona`,`id_tipo_archivo`,`nombre`,`ruta`,`registro`),
  KEY `id_tipo_archivo` (`id_tipo_archivo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_principal` (`id_principal`),
  KEY `id_persona` (`id_persona`),
  CONSTRAINT `tc_mantic_personas_archivos_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_personas_archivos_ibfk_2` FOREIGN KEY (`id_tipo_archivo`) REFERENCES `tc_mantic_tipos_archivos` (`id_tipo_archivo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_personas_archivos_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_personas_archivos_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_personas_titulos` */

DROP TABLE IF EXISTS `tc_mantic_personas_titulos`;

CREATE TABLE `tc_mantic_personas_titulos` (
  `id_persona_titulo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descrpcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_persona_titulo`),
  KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_proveedores` */

DROP TABLE IF EXISTS `tc_mantic_proveedores`;

CREATE TABLE `tc_mantic_proveedores` (
  `id_proveedor` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `clave` varchar(50) COLLATE latin1_bin NOT NULL,
  `prefijo` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `rfc` varchar(50) COLLATE latin1_bin DEFAULT NULL,
  `razon_social` varchar(255) COLLATE latin1_bin NOT NULL,
  `id_tipo_proveedor` bigint(11) unsigned NOT NULL,
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT '0.00',
  `dias_entrega` bigint(11) DEFAULT NULL,
  `id_tipo_dia` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_tipo_moneda` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_activo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `logotipo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor`),
  UNIQUE KEY `razon_social` (`razon_social`,`id_empresa`),
  KEY `id_tipo_proveedor` (`id_tipo_proveedor`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_tipo_dia` (`id_tipo_dia`),
  KEY `id_tipo_moneda` (`id_tipo_moneda`),
  KEY `id_activo` (`id_activo`),
  CONSTRAINT `tc_mantic_proveedores_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_proveedores_ibfk_2` FOREIGN KEY (`id_tipo_proveedor`) REFERENCES `tc_mantic_tipos_proveedores` (`id_tipo_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_proveedores_ibfk_3` FOREIGN KEY (`id_tipo_dia`) REFERENCES `tc_mantic_tipos_dias` (`id_tipo_dia`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_proveedores_ibfk_4` FOREIGN KEY (`id_tipo_moneda`) REFERENCES `tc_mantic_tipos_monedas` (`id_tipo_moneda`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_proveedores_ibfk_5` FOREIGN KEY (`id_activo`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_proveedores_bancos` */

DROP TABLE IF EXISTS `tc_mantic_proveedores_bancos`;

CREATE TABLE `tc_mantic_proveedores_bancos` (
  `id_proveedor_banca` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `id_banco` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_tipo_cuenta` bigint(11) unsigned NOT NULL DEFAULT '1',
  `convenio_cuenta` varchar(100) COLLATE latin1_bin NOT NULL,
  `clabe_referencia` varchar(100) COLLATE latin1_bin NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor_banca`),
  UNIQUE KEY `id_proveedor_uk` (`id_proveedor`,`clabe_referencia`,`id_proveedor_banca`,`id_tipo_cuenta`,`convenio_cuenta`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_tipo_cuenta` (`id_tipo_cuenta`),
  KEY `id_banco` (`id_banco`),
  CONSTRAINT `tc_mantic_proveedores_bancos_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_proveedores_bancos_ibfk_2` FOREIGN KEY (`id_tipo_cuenta`) REFERENCES `tc_mantic_tipos_cuentas` (`id_tipo_cuenta`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_proveedores_bancos_ibfk_3` FOREIGN KEY (`id_banco`) REFERENCES `tc_mantic_bancos` (`id_banco`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_proveedores_portales` */

DROP TABLE IF EXISTS `tc_mantic_proveedores_portales`;

CREATE TABLE `tc_mantic_proveedores_portales` (
  `id_proveedor_portal` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `pagina` varchar(255) COLLATE latin1_bin NOT NULL,
  `cuenta` varchar(100) COLLATE latin1_bin NOT NULL,
  `contrasenia` varchar(100) COLLATE latin1_bin NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor_portal`),
  UNIQUE KEY `id_proveedor_uk` (`id_proveedor`,`pagina`,`cuenta`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `tc_mantic_proveedores_portales_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_puestos` */

DROP TABLE IF EXISTS `tc_mantic_puestos`;

CREATE TABLE `tc_mantic_puestos` (
  `id_puesto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `clave` varchar(255) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` bigint(11) DEFAULT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_puesto`),
  KEY `id_empresa` (`id_empresa`,`clave`),
  KEY `id_empresa_2` (`id_empresa`),
  KEY `id_registro` (`id_usuario`),
  CONSTRAINT `tc_mantic_puestos_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_repetidos` */

DROP TABLE IF EXISTS `tc_mantic_repetidos`;

CREATE TABLE `tc_mantic_repetidos` (
  `id_repetido` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_repetido`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_requisiciones` */

DROP TABLE IF EXISTS `tc_mantic_requisiciones`;

CREATE TABLE `tc_mantic_requisiciones` (
  `id_requisicion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `consecutivo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_solicita` bigint(11) unsigned DEFAULT NULL,
  `fecha_pedido` date NOT NULL,
  `fecha_entregada` date DEFAULT NULL,
  `id_requisicion_estatus` bigint(11) unsigned NOT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_requisicion`),
  UNIQUE KEY `id_requisicion_uk` (`id_empresa`,`ejercicio`,`orden`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_solicita` (`id_solicita`),
  KEY `id_requisicion_estatus` (`id_requisicion_estatus`),
  CONSTRAINT `tc_mantic_requisiciones_ibfk_1` FOREIGN KEY (`id_solicita`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_requisiciones_ibfk_2` FOREIGN KEY (`id_requisicion_estatus`) REFERENCES `tc_mantic_requisiciones_estatus` (`id_requisicion_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_requisiciones_ibfk_3` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_requisiciones_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_requisiciones_bitacora`;

CREATE TABLE `tc_mantic_requisiciones_bitacora` (
  `id_requisicion_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_requisicion` bigint(11) unsigned NOT NULL,
  `id_requisicion_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_requisicion_bitacora`),
  UNIQUE KEY `id_requisicion_uk` (`id_requisicion`,`id_requisicion_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_requisicion` (`id_requisicion`),
  KEY `id_requisicion_estatus` (`id_requisicion_estatus`),
  CONSTRAINT `tc_mantic_requisiciones_bitacora_ibfk_1` FOREIGN KEY (`id_requisicion`) REFERENCES `tc_mantic_requisiciones` (`id_requisicion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_requisiciones_bitacora_ibfk_2` FOREIGN KEY (`id_requisicion_estatus`) REFERENCES `tc_mantic_requisiciones_estatus` (`id_requisicion_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_requisiciones_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_requisiciones_detalles` */

DROP TABLE IF EXISTS `tc_mantic_requisiciones_detalles`;

CREATE TABLE `tc_mantic_requisiciones_detalles` (
  `id_requisicion_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_requisicion` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `propio` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `unidad_medida` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `cantidad` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_requisicion_detalle`),
  UNIQUE KEY `id_requisicion_uk` (`id_requisicion`,`id_articulo`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_requisicion` (`id_requisicion`),
  CONSTRAINT `tc_mantic_requisiciones_detalles_ibfk_1` FOREIGN KEY (`id_requisicion`) REFERENCES `tc_mantic_requisiciones` (`id_requisicion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_requisiciones_detalles_ibfk_2` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_requisiciones_estatus` */

DROP TABLE IF EXISTS `tc_mantic_requisiciones_estatus`;

CREATE TABLE `tc_mantic_requisiciones_estatus` (
  `id_requisicion_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_requisicion_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_requisiciones_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_requisiciones_proveedores` */

DROP TABLE IF EXISTS `tc_mantic_requisiciones_proveedores`;

CREATE TABLE `tc_mantic_requisiciones_proveedores` (
  `id_requisicion_proveedor` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_requisicion` bigint(11) unsigned NOT NULL,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_requisicion_proveedor`),
  UNIQUE KEY `id_requisicion_uk` (`id_requisicion`,`id_proveedor`),
  KEY `id_articulo` (`id_proveedor`),
  KEY `id_requisicion` (`id_requisicion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_respaldos` */

DROP TABLE IF EXISTS `tc_mantic_respaldos`;

CREATE TABLE `tc_mantic_respaldos` (
  `id_respaldo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `ruta` varchar(500) COLLATE latin1_bin NOT NULL,
  `alias` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `tamanio` bigint(11) DEFAULT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `eliminado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activo` bigint(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_respaldo`),
  UNIQUE KEY `id_respaldos_uk` (`nombre`),
  KEY `id_usuario` (`id_usuario`),
  KEY `activo` (`activo`),
  CONSTRAINT `tc_mantic_respaldos_ibfk_1` FOREIGN KEY (`activo`) REFERENCES `tc_janal_booleanos` (`id_booleano`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_servicios` */

DROP TABLE IF EXISTS `tc_mantic_servicios`;

CREATE TABLE `tc_mantic_servicios` (
  `id_servicio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_particular` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_cliente` bigint(11) unsigned DEFAULT NULL,
  `cliente` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `telefonos` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `herramienta` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `marca` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `modelo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `caracteristicas` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `reparacion` varchar(800) COLLATE latin1_bin DEFAULT NULL,
  `fecha_estimada` date DEFAULT NULL,
  `id_servicio_estatus` bigint(11) unsigned NOT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) DEFAULT '0.0000',
  `sub_total` decimal(11,4) DEFAULT '0.0000',
  `total` decimal(11,4) DEFAULT '0.0000',
  `id_tipo_medio_pago` bigint(11) unsigned DEFAULT NULL,
  `id_factura` bigint(11) unsigned DEFAULT NULL,
  `efectivo` decimal(11,4) DEFAULT '0.0000',
  `id_garantia` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `id_venta` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_servicio`),
  UNIQUE KEY `id_empresa_uk` (`id_empresa`,`consecutivo`,`id_cliente`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_servicio_estatus` (`id_servicio_estatus`),
  KEY `id_garantia` (`id_garantia`),
  KEY `id_particular` (`id_particular`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tc_mantic_servicios_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_servicios_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_servicios_ibfk_3` FOREIGN KEY (`id_garantia`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_servicios_ibfk_4` FOREIGN KEY (`id_particular`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_servicios_ibfk_5` FOREIGN KEY (`id_venta`) REFERENCES `tc_mantic_ventas` (`id_venta`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_servicios_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_servicios_bitacora`;

CREATE TABLE `tc_mantic_servicios_bitacora` (
  `id_servicio_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_servicio` bigint(11) unsigned NOT NULL,
  `id_servicio_estatus` bigint(11) unsigned NOT NULL,
  `seguimiento` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `fecha_estimada` date DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `importe` decimal(11,2) DEFAULT '0.00',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_servicio_bitacora`),
  UNIQUE KEY `id_servicio_uk` (`id_servicio`,`id_servicio_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_servicio` (`id_servicio`),
  KEY `id_servicio_estatus` (`id_servicio_estatus`),
  CONSTRAINT `tc_mantic_servicios_bitacora_ibfk_3` FOREIGN KEY (`id_servicio_estatus`) REFERENCES `tc_mantic_servicios_estatus` (`id_servicio_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_servicios_bitacora_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_servicios_detalles` */

DROP TABLE IF EXISTS `tc_mantic_servicios_detalles`;

CREATE TABLE `tc_mantic_servicios_detalles` (
  `id_servicio_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_servicio` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned DEFAULT NULL,
  `codigo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `propio` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `concepto` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `cantidad` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `costo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `descuento` varchar(100) COLLATE latin1_bin NOT NULL,
  `iva` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) DEFAULT '0.0000',
  `sub_total` decimal(11,4) DEFAULT '0.0000',
  `importe` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_servicio_detalle`),
  UNIQUE KEY `id_servicio_uk` (`id_servicio`,`concepto`),
  KEY `id_servicio` (`id_servicio`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_servicios_detalles_ibfk_1` FOREIGN KEY (`id_servicio`) REFERENCES `tc_mantic_servicios` (`id_servicio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_servicios_detalles_ibfk_2` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_servicios_estatus` */

DROP TABLE IF EXISTS `tc_mantic_servicios_estatus`;

CREATE TABLE `tc_mantic_servicios_estatus` (
  `id_servicio_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_servicio_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_servicios_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_archivos` */

DROP TABLE IF EXISTS `tc_mantic_tipos_archivos`;

CREATE TABLE `tc_mantic_tipos_archivos` (
  `id_tipo_archivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `orden` bigint(11) DEFAULT NULL,
  `agrupador` bigint(11) DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_archivo`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_articulos` */

DROP TABLE IF EXISTS `tc_mantic_tipos_articulos`;

CREATE TABLE `tc_mantic_tipos_articulos` (
  `id_tipo_articulo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_articulo`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_cierres` */

DROP TABLE IF EXISTS `tc_mantic_tipos_cierres`;

CREATE TABLE `tc_mantic_tipos_cierres` (
  `id_tipo_cierre` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_cierre`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_colores` */

DROP TABLE IF EXISTS `tc_mantic_tipos_colores`;

CREATE TABLE `tc_mantic_tipos_colores` (
  `id_tipo_color` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_color`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_compras` */

DROP TABLE IF EXISTS `tc_mantic_tipos_compras`;

CREATE TABLE `tc_mantic_tipos_compras` (
  `id_tipo_compra` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_compra`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_contactos` */

DROP TABLE IF EXISTS `tc_mantic_tipos_contactos`;

CREATE TABLE `tc_mantic_tipos_contactos` (
  `id_tipo_contacto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descrpcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_tipo_medio` bigint(11) unsigned NOT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_contacto`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_tipo_medio` (`id_tipo_medio`),
  CONSTRAINT `tc_mantic_tipos_contactos_ibfk_1` FOREIGN KEY (`id_tipo_medio`) REFERENCES `tc_mantic_tipos_medios` (`id_tipo_medio`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_creditos_notas` */

DROP TABLE IF EXISTS `tc_mantic_tipos_creditos_notas`;

CREATE TABLE `tc_mantic_tipos_creditos_notas` (
  `id_tipo_credito_nota` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_credito_nota`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_cuentas` */

DROP TABLE IF EXISTS `tc_mantic_tipos_cuentas`;

CREATE TABLE `tc_mantic_tipos_cuentas` (
  `id_tipo_cuenta` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_cuenta`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_dias` */

DROP TABLE IF EXISTS `tc_mantic_tipos_dias`;

CREATE TABLE `tc_mantic_tipos_dias` (
  `id_tipo_dia` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_dia`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_documentos` */

DROP TABLE IF EXISTS `tc_mantic_tipos_documentos`;

CREATE TABLE `tc_mantic_tipos_documentos` (
  `id_tipo_documento` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_documento`),
  UNIQUE KEY `descripcion` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_domicilios` */

DROP TABLE IF EXISTS `tc_mantic_tipos_domicilios`;

CREATE TABLE `tc_mantic_tipos_domicilios` (
  `id_tipo_domicilio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_domicilio`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_tipos_domicilios_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_empresas` */

DROP TABLE IF EXISTS `tc_mantic_tipos_empresas`;

CREATE TABLE `tc_mantic_tipos_empresas` (
  `id_tipo_empresa` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_empresa`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_tipos_empresas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_imagenes` */

DROP TABLE IF EXISTS `tc_mantic_tipos_imagenes`;

CREATE TABLE `tc_mantic_tipos_imagenes` (
  `id_tipo_imagen` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_imagen`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_incidentes` */

DROP TABLE IF EXISTS `tc_mantic_tipos_incidentes`;

CREATE TABLE `tc_mantic_tipos_incidentes` (
  `id_tipo_incidente` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_incidente`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_masivos` */

DROP TABLE IF EXISTS `tc_mantic_tipos_masivos`;

CREATE TABLE `tc_mantic_tipos_masivos` (
  `id_tipo_masivo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_masivo`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_medios` */

DROP TABLE IF EXISTS `tc_mantic_tipos_medios`;

CREATE TABLE `tc_mantic_tipos_medios` (
  `id_tipo_medio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_medio`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_medios_pagos` */

DROP TABLE IF EXISTS `tc_mantic_tipos_medios_pagos`;

CREATE TABLE `tc_mantic_tipos_medios_pagos` (
  `id_tipo_medio_pago` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_cobro_caja` bigint(11) unsigned NOT NULL DEFAULT '2',
  `orden` bigint(11) DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_medio_pago`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cobro_caja` (`id_cobro_caja`),
  CONSTRAINT `tc_mantic_tipos_medios_pagos_ibfk_1` FOREIGN KEY (`id_cobro_caja`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_monedas` */

DROP TABLE IF EXISTS `tc_mantic_tipos_monedas`;

CREATE TABLE `tc_mantic_tipos_monedas` (
  `id_tipo_moneda` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `siglas` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `simbolo` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_moneda`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_movimientos` */

DROP TABLE IF EXISTS `tc_mantic_tipos_movimientos`;

CREATE TABLE `tc_mantic_tipos_movimientos` (
  `id_tipo_movimiento` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_movimiento`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_pagos` */

DROP TABLE IF EXISTS `tc_mantic_tipos_pagos`;

CREATE TABLE `tc_mantic_tipos_pagos` (
  `id_tipo_pago` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_pago`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_personas` */

DROP TABLE IF EXISTS `tc_mantic_tipos_personas`;

CREATE TABLE `tc_mantic_tipos_personas` (
  `id_tipo_persona` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_persona`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_proveedores` */

DROP TABLE IF EXISTS `tc_mantic_tipos_proveedores`;

CREATE TABLE `tc_mantic_tipos_proveedores` (
  `id_tipo_proveedor` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `dias` bigint(11) NOT NULL DEFAULT '1',
  `id_tipo_dia` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_proveedor`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_tipo_dia` (`id_tipo_dia`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_reportes` */

DROP TABLE IF EXISTS `tc_mantic_tipos_reportes`;

CREATE TABLE `tc_mantic_tipos_reportes` (
  `id_tipo_reporte` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_reporte`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_tallas` */

DROP TABLE IF EXISTS `tc_mantic_tipos_tallas`;

CREATE TABLE `tc_mantic_tipos_tallas` (
  `id_tipo_talla` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(50) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_tipo_articulo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `orden` bigint(11) DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_talla`,`clave`,`nombre`),
  UNIQUE KEY `clave` (`clave`,`nombre`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_tipo_articulo` (`id_tipo_articulo`),
  CONSTRAINT `tc_mantic_tipos_tallas_ibfk_1` FOREIGN KEY (`id_tipo_articulo`) REFERENCES `tc_mantic_tipos_articulos` (`id_tipo_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_tipos_ventas` */

DROP TABLE IF EXISTS `tc_mantic_tipos_ventas`;

CREATE TABLE `tc_mantic_tipos_ventas` (
  `id_tipo_venta` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `porcentaje_utilidad` bigint(11) DEFAULT '30',
  `limite` bigint(11) NOT NULL DEFAULT '10',
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_venta`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_trabajos` */

DROP TABLE IF EXISTS `tc_mantic_trabajos`;

CREATE TABLE `tc_mantic_trabajos` (
  `id_trabajo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `sat` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `codigo` varchar(100) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `herramienta` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `iva` decimal(11,2) NOT NULL DEFAULT '0.00',
  `precio` decimal(11,2) NOT NULL DEFAULT '0.00',
  `id_vigente` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_trabajo`),
  UNIQUE KEY `nombre` (`id_empresa`,`codigo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_vigente` (`id_vigente`),
  CONSTRAINT `tc_mantic_trabajos_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_trabajos_ibfk_2` FOREIGN KEY (`id_vigente`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_transferencias` */

DROP TABLE IF EXISTS `tc_mantic_transferencias`;

CREATE TABLE `tc_mantic_transferencias` (
  `id_transferencia` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL DEFAULT '1',
  `consecutivo` varchar(100) COLLATE latin1_bin NOT NULL,
  `id_almacen` bigint(11) unsigned NOT NULL,
  `id_destino` bigint(11) unsigned NOT NULL,
  `id_solicito` bigint(11) unsigned DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `id_transferencia_estatus` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_transferencia_tipo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_transferencia`),
  KEY `id_almacen` (`id_almacen`),
  KEY `id_destino` (`id_destino`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_solicito` (`id_solicito`),
  KEY `id_transferencia_estatus` (`id_transferencia_estatus`),
  KEY `id_transferencia_tipo` (`id_transferencia_tipo`),
  KEY `id_empresa` (`id_empresa`),
  CONSTRAINT `tc_mantic_transferencias_ibfk_1` FOREIGN KEY (`id_almacen`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_transferencias_ibfk_2` FOREIGN KEY (`id_destino`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_transferencias_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_transferencias_ibfk_5` FOREIGN KEY (`id_solicito`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_transferencias_ibfk_6` FOREIGN KEY (`id_transferencia_estatus`) REFERENCES `tc_mantic_transferencias_estatus` (`id_transferencia_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_transferencias_ibfk_7` FOREIGN KEY (`id_transferencia_tipo`) REFERENCES `tc_mantic_transferencias_tipos` (`id_transferencia_tipo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_transferencias_ibfk_8` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_transferencias_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_transferencias_bitacora`;

CREATE TABLE `tc_mantic_transferencias_bitacora` (
  `id_transferencia_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_transferencia` bigint(11) unsigned NOT NULL,
  `id_transferencia_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_transporto` bigint(11) unsigned DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_transferencia_bitacora`),
  UNIQUE KEY `id_transferencia_uk` (`id_transferencia`,`id_transferencia_estatus`,`registro`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_transferencia` (`id_transferencia`),
  KEY `id_transferencia_estatus` (`id_transferencia_estatus`),
  KEY `id_transporto` (`id_transporto`),
  CONSTRAINT `tc_mantic_transferencias_bitacora_ibfk_1` FOREIGN KEY (`id_transferencia`) REFERENCES `tc_mantic_transferencias` (`id_transferencia`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_transferencias_bitacora_ibfk_2` FOREIGN KEY (`id_transferencia_estatus`) REFERENCES `tc_mantic_transferencias_estatus` (`id_transferencia_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_transferencias_bitacora_ibfk_4` FOREIGN KEY (`id_transporto`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_transferencias_detalles` */

DROP TABLE IF EXISTS `tc_mantic_transferencias_detalles`;

CREATE TABLE `tc_mantic_transferencias_detalles` (
  `id_transferencia_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_transferencia` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `codigo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `cantidad` decimal(11,4) DEFAULT NULL,
  `cantidades` decimal(11,4) DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_transferencia_detalle`),
  UNIQUE KEY `id_transferencia_uk` (`id_transferencia`,`id_articulo`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_transferencia` (`id_transferencia`),
  CONSTRAINT `tc_mantic_transferencias_detalles_ibfk_1` FOREIGN KEY (`id_transferencia`) REFERENCES `tc_mantic_transferencias` (`id_transferencia`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_transferencias_detalles_ibfk_2` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_transferencias_estatus` */

DROP TABLE IF EXISTS `tc_mantic_transferencias_estatus`;

CREATE TABLE `tc_mantic_transferencias_estatus` (
  `id_transferencia_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_transferencia_estatus`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_justificacion` (`id_justificacion`),
  CONSTRAINT `tc_mantic_transferencias_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_transferencias_tipos` */

DROP TABLE IF EXISTS `tc_mantic_transferencias_tipos`;

CREATE TABLE `tc_mantic_transferencias_tipos` (
  `id_transferencia_tipo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_transferencia_tipo`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_transferencias_tipos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_unidades_medidas` */

DROP TABLE IF EXISTS `tc_mantic_unidades_medidas`;

CREATE TABLE `tc_mantic_unidades_medidas` (
  `id_unidad_medida` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin NOT NULL,
  `descripcion` varbinary(500) DEFAULT NULL,
  `proporcion` decimal(11,0) NOT NULL DEFAULT '0',
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_unidad_medida`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_usos_cfdi` */

DROP TABLE IF EXISTS `tc_mantic_usos_cfdi`;

CREATE TABLE `tc_mantic_usos_cfdi` (
  `id_uso_cfdi` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(255) COLLATE latin1_bin NOT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `descripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_uso_cfdi`),
  UNIQUE KEY `clave` (`clave`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ventas` */

DROP TABLE IF EXISTS `tc_mantic_ventas`;

CREATE TABLE `tc_mantic_ventas` (
  `id_venta` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `consecutivo` bigint(11) NOT NULL,
  `id_almacen` bigint(11) unsigned NOT NULL,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `id_cliente_domicilio` bigint(11) unsigned DEFAULT NULL,
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `extras` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `impuestos` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `sub_total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `tipo_de_cambio` decimal(11,4) DEFAULT '0.0000',
  `dia` date NOT NULL,
  `id_venta_estatus` bigint(11) unsigned NOT NULL,
  `id_sin_iva` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_factura` bigint(11) unsigned DEFAULT '2',
  `id_facturar` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_uso_cfdi` bigint(11) unsigned DEFAULT NULL,
  `ejercicio` bigint(11) NOT NULL,
  `orden` bigint(11) NOT NULL,
  `id_credito` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_autorizar` bigint(11) unsigned NOT NULL DEFAULT '2',
  `global` decimal(11,4) DEFAULT '0.0000',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `utilidad` decimal(11,4) DEFAULT '0.0000',
  `ticket` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `cticket` bigint(11) unsigned DEFAULT NULL,
  `cotizacion` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `ccotizacion` bigint(11) unsigned DEFAULT NULL,
  `vigencia` date DEFAULT NULL,
  `id_manual` bigint(11) unsigned NOT NULL DEFAULT '2',
  `cobro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_tipo_medio_pago` bigint(11) unsigned DEFAULT NULL,
  `id_tipo_pago` bigint(11) unsigned DEFAULT NULL,
  `id_banco` bigint(11) unsigned DEFAULT NULL,
  `referencia` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `candado` bigint(1) unsigned NOT NULL DEFAULT '2',
  `id_tipo_documento` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_sincronizado` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_venta`),
  UNIQUE KEY `consecutivo` (`consecutivo`,`dia`,`id_empresa`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_venta_estatus` (`id_venta_estatus`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_factura` (`id_factura`),
  KEY `id_almacen` (`id_almacen`),
  KEY `id_sin_iva` (`id_sin_iva`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_uso_cfdi` (`id_uso_cfdi`),
  KEY `id_credito` (`id_credito`),
  KEY `id_autorizar` (`id_autorizar`),
  KEY `id_manual` (`id_manual`),
  KEY `id_venta` (`id_venta_estatus`,`registro`),
  KEY `id_facturar` (`id_facturar`),
  KEY `id_cliente_domicilio` (`id_cliente_domicilio`),
  KEY `id_tipo_medio_pago` (`id_tipo_medio_pago`),
  KEY `id_tipo_pago` (`id_tipo_pago`),
  KEY `id_banco` (`id_banco`),
  KEY `candado` (`candado`),
  KEY `id_sincronizado` (`id_sincronizado`),
  KEY `id_tipo_documento` (`id_tipo_documento`),
  CONSTRAINT `tc_mantic_ventas_ibfk_10` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_11` FOREIGN KEY (`id_manual`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_12` FOREIGN KEY (`id_facturar`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_13` FOREIGN KEY (`id_factura`) REFERENCES `tc_mantic_facturas` (`id_factura`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_14` FOREIGN KEY (`id_cliente_domicilio`) REFERENCES `tr_mantic_cliente_domicilio` (`id_cliente_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_15` FOREIGN KEY (`id_tipo_medio_pago`) REFERENCES `tc_mantic_tipos_medios_pagos` (`id_tipo_medio_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_16` FOREIGN KEY (`id_tipo_pago`) REFERENCES `tc_mantic_tipos_pagos` (`id_tipo_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_17` FOREIGN KEY (`id_banco`) REFERENCES `tc_mantic_bancos` (`id_banco`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_19` FOREIGN KEY (`candado`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_20` FOREIGN KEY (`id_sincronizado`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_21` FOREIGN KEY (`id_tipo_documento`) REFERENCES `tc_mantic_tipos_documentos` (`id_tipo_documento`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_4` FOREIGN KEY (`id_almacen`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_5` FOREIGN KEY (`id_sin_iva`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_6` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_7` FOREIGN KEY (`id_uso_cfdi`) REFERENCES `tc_mantic_usos_cfdi` (`id_uso_cfdi`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_8` FOREIGN KEY (`id_credito`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_ibfk_9` FOREIGN KEY (`id_autorizar`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ventas_bitacora` */

DROP TABLE IF EXISTS `tc_mantic_ventas_bitacora`;

CREATE TABLE `tc_mantic_ventas_bitacora` (
  `id_venta_bitacora` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_venta` bigint(11) unsigned NOT NULL,
  `id_venta_estatus` bigint(11) unsigned NOT NULL,
  `justificacion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `consecutivo` bigint(11) NOT NULL DEFAULT '0',
  `importe` decimal(11,2) NOT NULL DEFAULT '0.00',
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_venta_bitacora`),
  UNIQUE KEY `id_venta_uk` (`id_venta`,`id_venta_estatus`,`registro`),
  KEY `id_venta` (`id_venta`),
  KEY `id_venta_estatus` (`id_venta_estatus`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tc_mantic_ventas_bitacora_ibfk_1` FOREIGN KEY (`id_venta`) REFERENCES `tc_mantic_ventas` (`id_venta`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_bitacora_ibfk_2` FOREIGN KEY (`id_venta_estatus`) REFERENCES `tc_mantic_ventas_estatus` (`id_venta_estatus`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_bitacora_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ventas_detalles` */

DROP TABLE IF EXISTS `tc_mantic_ventas_detalles`;

CREATE TABLE `tc_mantic_ventas_detalles` (
  `id_venta_detalle` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_venta` bigint(11) unsigned NOT NULL,
  `id_articulo` bigint(11) unsigned DEFAULT NULL,
  `codigo` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `sat` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `cantidad` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `precio` decimal(11,4) DEFAULT '0.0000',
  `costo` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `descuento` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `extras` varchar(100) COLLATE latin1_bin DEFAULT '0',
  `descuentos` decimal(11,4) DEFAULT '0.0000',
  `iva` decimal(11,4) DEFAULT '16.0000',
  `impuestos` decimal(11,4) DEFAULT '0.0000',
  `sub_total` decimal(11,4) DEFAULT '0.0000',
  `importe` decimal(11,4) DEFAULT '0.0000',
  `unidad_medida` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `utilidad` decimal(11,4) DEFAULT '0.0000',
  `unitario_sin_iva` decimal(11,4) DEFAULT '0.0000',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_venta_detalle`),
  UNIQUE KEY `id_venta_articulo` (`id_venta`,`id_articulo`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tc_mantic_ventas_detalles_ibfk_1` FOREIGN KEY (`id_venta`) REFERENCES `tc_mantic_ventas` (`id_venta`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_detalles_ibfk_2` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tc_mantic_ventas_estatus` */

DROP TABLE IF EXISTS `tc_mantic_ventas_estatus`;

CREATE TABLE `tc_mantic_ventas_estatus` (
  `id_venta_estatus` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(500) COLLATE latin1_bin NOT NULL,
  `decripcion` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `estatus_asociados` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_justificacion` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_tipo_documento` bigint(11) unsigned NOT NULL DEFAULT '2',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_venta_estatus`),
  UNIQUE KEY `nombre` (`nombre`,`id_tipo_documento`),
  KEY `id_justificacion` (`id_justificacion`),
  KEY `id_tipo_venta` (`id_tipo_documento`),
  CONSTRAINT `tc_mantic_ventas_estatus_ibfk_1` FOREIGN KEY (`id_justificacion`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tc_mantic_ventas_estatus_ibfk_3` FOREIGN KEY (`id_tipo_documento`) REFERENCES `tc_mantic_tipos_documentos` (`id_tipo_documento`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_bitacora_movil` */

DROP TABLE IF EXISTS `tr_janal_bitacora_movil`;

CREATE TABLE `tr_janal_bitacora_movil` (
  `id_bitacora_movil` bigint(11) NOT NULL AUTO_INCREMENT,
  `id_muestra` bigint(11) NOT NULL,
  `cuestionario` varchar(5000) COLLATE latin1_bin DEFAULT NULL,
  `visitas` varchar(5000) COLLATE latin1_bin DEFAULT NULL,
  `registro_integracion` timestamp(6) NULL DEFAULT NULL,
  `cuenta` varchar(50) COLLATE latin1_bin NOT NULL,
  `id_estatus` bigint(11) NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bitacora_movil`),
  UNIQUE KEY `UK_BITACORAWS` (`id_bitacora_movil`,`id_muestra`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_buzon` */

DROP TABLE IF EXISTS `tr_janal_buzon`;

CREATE TABLE `tr_janal_buzon` (
  `id_buzon` bigint(15) unsigned NOT NULL AUTO_INCREMENT,
  `id_modulo` bigint(15) unsigned NOT NULL,
  `id_usuario` bigint(15) unsigned NOT NULL,
  `descripcion` varchar(1000) COLLATE latin1_bin DEFAULT NULL,
  `registro` datetime DEFAULT NULL,
  `id_problematica` bigint(11) unsigned NOT NULL,
  `pagina` varchar(300) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id_buzon`),
  UNIQUE KEY `tr_janal_buzon_uk1` (`registro`),
  KEY `tciktpro_triktbuz_fk` (`id_problematica`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_modulo` (`id_modulo`),
  CONSTRAINT `tr_janal_buzon_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_buzon_ibfk_2` FOREIGN KEY (`id_problematica`) REFERENCES `tc_janal_problematicas` (`id_problematica`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_buzon_ibfk_3` FOREIGN KEY (`id_modulo`) REFERENCES `tc_janal_modulos` (`id_modulo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_entidades_grupo` */

DROP TABLE IF EXISTS `tr_janal_entidades_grupo`;

CREATE TABLE `tr_janal_entidades_grupo` (
  `id_entidad_grupo` bigint(11) DEFAULT NULL,
  `id_grupo` bigint(11) unsigned NOT NULL,
  `id_entidad` bigint(11) unsigned NOT NULL,
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_mensajes_grupos` */

DROP TABLE IF EXISTS `tr_janal_mensajes_grupos`;

CREATE TABLE `tr_janal_mensajes_grupos` (
  `id_mensaje_grupo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_mensaje` bigint(11) unsigned NOT NULL,
  `id_grupo` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` bigint(11) unsigned NOT NULL,
  PRIMARY KEY (`id_mensaje_grupo`),
  UNIQUE KEY `primary_90` (`id_mensaje_grupo`),
  UNIQUE KEY `tr_janal_mensajes_grupos_uk1` (`id_mensaje`,`id_grupo`),
  KEY `tr_janal_mensajes_grupos_ibfk_` (`id_mensaje`),
  KEY `tr_janal_mensajes_grupos_ibf_1` (`id_grupo`),
  KEY `tr_janal_mensajes_grupos_ibf_2` (`id_usuario`),
  CONSTRAINT `tr_janal_mensajes_grupos_ibfk_1` FOREIGN KEY (`id_mensaje`) REFERENCES `tc_janal_mensajes` (`id_mensaje`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_mensajes_grupos_ibfk_2` FOREIGN KEY (`id_grupo`) REFERENCES `tc_janal_grupos` (`id_grupo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_mensajes_grupos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_mensajes_perfiles` */

DROP TABLE IF EXISTS `tr_janal_mensajes_perfiles`;

CREATE TABLE `tr_janal_mensajes_perfiles` (
  `id_mensaje_perfil` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_mensaje` bigint(11) unsigned NOT NULL,
  `id_perfil` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_mensaje_perfil`),
  UNIQUE KEY `primary_46` (`id_mensaje_perfil`),
  UNIQUE KEY `tr_janal_mensajes_perfile_uk1` (`id_mensaje`,`id_perfil`),
  KEY `tr_janal_mensajes_perfiles_ibf` (`id_mensaje`),
  KEY `tr_janal_mensajes_perfiles_i_1` (`id_perfil`),
  KEY `tr_janal_mensajes_perfiles_i_2` (`id_usuario`),
  CONSTRAINT `tr_janal_mensajes_perfiles_ibfk_1` FOREIGN KEY (`id_mensaje`) REFERENCES `tc_janal_mensajes` (`id_mensaje`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_mensajes_perfiles_ibfk_2` FOREIGN KEY (`id_perfil`) REFERENCES `tc_janal_perfiles` (`id_perfil`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_mensajes_perfiles_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_mensajes_usuarios` */

DROP TABLE IF EXISTS `tr_janal_mensajes_usuarios`;

CREATE TABLE `tr_janal_mensajes_usuarios` (
  `id_mensaje_usuario` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_mensaje` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `id_booleano` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_modifica` bigint(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_mensaje_usuario`),
  UNIQUE KEY `primary_62` (`id_mensaje_usuario`),
  UNIQUE KEY `tr_janal_mensajes_usuario_uk1` (`id_mensaje_usuario`,`registro`),
  KEY `tr_janal_mensajes_usuarios_ibf` (`id_booleano`),
  KEY `tr_janal_mensajes_usuarios_i_1` (`id_usuario`),
  KEY `tr_janal_mensajes_usuarios_i_2` (`id_mensaje`),
  KEY `tr_janal_mensajes_usuarios_i_3` (`id_usuario_modifica`),
  CONSTRAINT `tr_janal_mensajes_usuarios_ibfk_1` FOREIGN KEY (`id_mensaje`) REFERENCES `tc_janal_mensajes` (`id_mensaje`),
  CONSTRAINT `tr_janal_mensajes_usuarios_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`),
  CONSTRAINT `tr_janal_mensajes_usuarios_ibfk_3` FOREIGN KEY (`id_booleano`) REFERENCES `tc_janal_booleanos` (`id_booleano`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_menus_enc_perfil` */

DROP TABLE IF EXISTS `tr_janal_menus_enc_perfil`;

CREATE TABLE `tr_janal_menus_enc_perfil` (
  `id_menu_enc_perfil` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_perfil` bigint(11) unsigned NOT NULL,
  `id_menu_encabezado` bigint(11) unsigned NOT NULL,
  PRIMARY KEY (`id_menu_enc_perfil`),
  UNIQUE KEY `tr_janal_menus_enc_perfil_uk1` (`id_perfil`,`id_menu_encabezado`),
  KEY `id_menu_encabezado` (`id_menu_encabezado`),
  CONSTRAINT `tr_janal_menus_enc_perfil_ibfk_1` FOREIGN KEY (`id_perfil`) REFERENCES `tc_janal_perfiles` (`id_perfil`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_menus_enc_perfil_ibfk_2` FOREIGN KEY (`id_menu_encabezado`) REFERENCES `tc_janal_menus_encabezado` (`id_menu_encabezado`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_menus_grupos` */

DROP TABLE IF EXISTS `tr_janal_menus_grupos`;

CREATE TABLE `tr_janal_menus_grupos` (
  `id_menu_grupo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_menu` bigint(11) unsigned NOT NULL,
  `id_grupo` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_menu_grupo`),
  UNIQUE KEY `primary_28` (`id_menu_grupo`),
  UNIQUE KEY `tr_janal_menus_grupos_uk1` (`id_menu`,`id_grupo`),
  KEY `tr_kajool_menus_grupos_ibfk_1` (`id_menu`),
  KEY `tr_kajool_menus_grupos_ibfk_2` (`id_grupo`),
  KEY `tr_kajool_menus_grupos_ibfk_3` (`id_usuario`),
  CONSTRAINT `tr_janal_menus_grupos_ibfk_1` FOREIGN KEY (`id_menu`) REFERENCES `tc_janal_menus` (`id_menu`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_menus_grupos_ibfk_2` FOREIGN KEY (`id_grupo`) REFERENCES `tc_janal_grupos` (`id_grupo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_menus_grupos_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=490 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_menus_perfiles` */

DROP TABLE IF EXISTS `tr_janal_menus_perfiles`;

CREATE TABLE `tr_janal_menus_perfiles` (
  `id_menu_perfil` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_menu_grupo` bigint(11) unsigned NOT NULL,
  `id_perfil` bigint(11) unsigned NOT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL DEFAULT '1',
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_menu_perfil`),
  UNIQUE KEY `primary_29` (`id_menu_perfil`),
  UNIQUE KEY `trkajoolmenusperfiles_uk` (`id_menu_grupo`,`id_perfil`),
  KEY `tr_kajool_menus_perfiles_ibfk_1` (`id_menu_grupo`),
  KEY `tr_kajool_menus_perfiles_ibfk_2` (`id_perfil`),
  KEY `tr_kajool_menus_perfiles_ibfk_3` (`id_usuario`),
  CONSTRAINT `tr_janal_menus_perfiles_ibfk_1` FOREIGN KEY (`id_menu_grupo`) REFERENCES `tr_janal_menus_grupos` (`id_menu_grupo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_menus_perfiles_ibfk_2` FOREIGN KEY (`id_perfil`) REFERENCES `tc_janal_perfiles` (`id_perfil`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_janal_menus_perfiles_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=694 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_perfiles_jerarquias` */

DROP TABLE IF EXISTS `tr_janal_perfiles_jerarquias`;

CREATE TABLE `tr_janal_perfiles_jerarquias` (
  `id_perfil_jerarquia` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_perfil` bigint(11) unsigned NOT NULL,
  `id_perfil_alta` bigint(11) unsigned NOT NULL,
  `orden` int(2) DEFAULT NULL,
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_perfil_jerarquia`),
  UNIQUE KEY `tr_janal_perfiles_jerarqu_uk1` (`id_perfil`,`id_perfil_alta`),
  KEY `trper_trperjer_fk2` (`id_perfil_alta`),
  CONSTRAINT `tr_janal_perfiles_jerarquias_ibfk_1` FOREIGN KEY (`id_perfil`) REFERENCES `tc_janal_perfiles` (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_janal_usuarios_delega` */

DROP TABLE IF EXISTS `tr_janal_usuarios_delega`;

CREATE TABLE `tr_janal_usuarios_delega` (
  `id_usuario_delega` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `id_empleado` bigint(11) unsigned NOT NULL,
  `vigencia_ini` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vigencia_fin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activo` int(1) NOT NULL,
  `login` varchar(50) COLLATE latin1_bin NOT NULL,
  `contrasenia` varchar(50) COLLATE latin1_bin NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario_delega`),
  UNIQUE KEY `triktanusariosdelega_uk` (`id_usuario`,`id_empleado`,`vigencia_ini`),
  KEY `tr_janal_usarios_delega_t_fk1` (`id_empleado`),
  CONSTRAINT `tr_janal_usuarios_delega_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_almacen_domicilio` */

DROP TABLE IF EXISTS `tr_mantic_almacen_domicilio`;

CREATE TABLE `tr_mantic_almacen_domicilio` (
  `id_almacen_domicilio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_almacen` bigint(11) unsigned NOT NULL,
  `id_domicilio` bigint(11) unsigned NOT NULL,
  `id_tipo_domicilio` bigint(11) unsigned NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_almacen_domicilio`),
  UNIQUE KEY `id_almacen` (`id_almacen`,`id_domicilio`,`id_tipo_domicilio`,`id_principal`),
  KEY `id_domicilio` (`id_domicilio`),
  KEY `id_tipo_domicilio` (`id_tipo_domicilio`),
  KEY `id_principal` (`id_principal`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_almacen_2` (`id_almacen`),
  CONSTRAINT `tr_mantic_almacen_domicilio_ibfk_1` FOREIGN KEY (`id_almacen`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_almacen_domicilio_ibfk_2` FOREIGN KEY (`id_domicilio`) REFERENCES `tc_mantic_domicilios` (`id_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_almacen_domicilio_ibfk_3` FOREIGN KEY (`id_tipo_domicilio`) REFERENCES `tc_mantic_tipos_domicilios` (`id_tipo_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_almacen_domicilio_ibfk_4` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_almacen_domicilio_ibfk_5` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_almacen_tipo_contacto` */

DROP TABLE IF EXISTS `tr_mantic_almacen_tipo_contacto`;

CREATE TABLE `tr_mantic_almacen_tipo_contacto` (
  `id_almacen_tipo_contacto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_almacen` bigint(11) unsigned NOT NULL,
  `id_tipo_contacto` bigint(11) unsigned NOT NULL,
  `valor` varchar(255) COLLATE latin1_bin NOT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_almacen_tipo_contacto`),
  UNIQUE KEY `id_almacen` (`id_almacen`,`id_tipo_contacto`),
  KEY `id_tipo_contacto` (`id_tipo_contacto`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_almacen_2` (`id_almacen`),
  CONSTRAINT `tr_mantic_almacen_tipo_contacto_ibfk_1` FOREIGN KEY (`id_almacen`) REFERENCES `tc_mantic_almacenes` (`id_almacen`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_almacen_tipo_contacto_ibfk_2` FOREIGN KEY (`id_tipo_contacto`) REFERENCES `tc_mantic_tipos_contactos` (`id_tipo_contacto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_almacen_tipo_contacto_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_articulo_grupo_descuento` */

DROP TABLE IF EXISTS `tr_mantic_articulo_grupo_descuento`;

CREATE TABLE `tr_mantic_articulo_grupo_descuento` (
  `id_articulo_grupo_descuento` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `id_grupo` bigint(11) unsigned NOT NULL,
  `porcentaje` decimal(11,2) NOT NULL DEFAULT '0.00',
  `vigencia_inicial` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vigencia_final` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `observaciones` varchar(500) COLLATE utf16_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_grupo_descuento`),
  UNIQUE KEY `id_articulo` (`id_articulo`,`id_grupo`,`porcentaje`,`vigencia_inicial`,`vigencia_final`),
  KEY `id_articulo_2` (`id_articulo`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_grupo` (`id_grupo`),
  CONSTRAINT `tr_mantic_articulo_grupo_descuento_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulo_grupo_descuento_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulo_grupo_descuento_ibfk_4` FOREIGN KEY (`id_grupo`) REFERENCES `tc_mantic_grupos` (`id_grupo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

/*Table structure for table `tr_mantic_articulo_precio_sugerido` */

DROP TABLE IF EXISTS `tr_mantic_articulo_precio_sugerido`;

CREATE TABLE `tr_mantic_articulo_precio_sugerido` (
  `id_articulo_precio_sugerido` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `precio` decimal(11,2) NOT NULL DEFAULT '0.00',
  `descuento` decimal(11,2) NOT NULL DEFAULT '0.00',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_leido` bigint(11) unsigned NOT NULL DEFAULT '2',
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_precio_sugerido`),
  UNIQUE KEY `id_articulo` (`id_articulo`,`id_proveedor`,`precio`,`descuento`),
  KEY `id_articulo_2` (`id_articulo`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_leido` (`id_leido`),
  CONSTRAINT `tr_mantic_articulo_precio_sugerido_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulo_precio_sugerido_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulo_precio_sugerido_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulo_precio_sugerido_ibfk_4` FOREIGN KEY (`id_leido`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_articulo_presentacion` */

DROP TABLE IF EXISTS `tr_mantic_articulo_presentacion`;

CREATE TABLE `tr_mantic_articulo_presentacion` (
  `id_articulo_presentacion` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `id_empaque_unidad_medida` bigint(11) unsigned NOT NULL,
  `cantidad` bigint(11) NOT NULL DEFAULT '0',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_presentacion`),
  UNIQUE KEY `id_articulo_uk` (`id_articulo`,`id_empaque_unidad_medida`),
  KEY `id_articulo_presentacion` (`id_articulo_presentacion`),
  KEY `id_presentacion_unidad_medida` (`id_empaque_unidad_medida`),
  KEY `id_articulo` (`id_articulo`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tr_mantic_articulo_presentacion_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulo_presentacion_ibfk_2` FOREIGN KEY (`id_empaque_unidad_medida`) REFERENCES `tr_mantic_empaque_unidad_medida` (`id_empaque_unidad_medida`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulo_presentacion_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_articulo_proveedor` */

DROP TABLE IF EXISTS `tr_mantic_articulo_proveedor`;

CREATE TABLE `tr_mantic_articulo_proveedor` (
  `id_articulo_proveedor` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `cantidad` decimal(11,2) NOT NULL DEFAULT '0.00',
  `precio` decimal(11,2) NOT NULL DEFAULT '0.00',
  `descuento` decimal(11,2) NOT NULL DEFAULT '0.00',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `fecha_compra` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_proveedor`),
  UNIQUE KEY `id_articulo` (`id_articulo`,`id_proveedor`,`registro`),
  KEY `id_articulo_2` (`id_articulo`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_articulo_tipo_venta` */

DROP TABLE IF EXISTS `tr_mantic_articulo_tipo_venta`;

CREATE TABLE `tr_mantic_articulo_tipo_venta` (
  `id_articulo_tipo_venta` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `id_tipo_venta` bigint(11) unsigned NOT NULL,
  `porcentaje` decimal(11,2) NOT NULL DEFAULT '0.00',
  `orden` bigint(11) DEFAULT '1',
  `id_registro` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_tipo_venta`),
  UNIQUE KEY `id_articulo` (`id_articulo`,`id_tipo_venta`),
  KEY `id_articulo_2` (`id_articulo`),
  KEY `id_tipo_venta` (`id_tipo_venta`),
  KEY `id_registro` (`id_registro`),
  CONSTRAINT `tr_mantic_articulo_tipo_venta_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulo_tipo_venta_ibfk_2` FOREIGN KEY (`id_tipo_venta`) REFERENCES `tc_mantic_tipos_ventas` (`id_tipo_venta`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulo_tipo_venta_ibfk_3` FOREIGN KEY (`id_registro`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_articulos_precios_ofertados` */

DROP TABLE IF EXISTS `tr_mantic_articulos_precios_ofertados`;

CREATE TABLE `tr_mantic_articulos_precios_ofertados` (
  `id_articulo_precio_ofertado` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_articulo` bigint(11) unsigned NOT NULL,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `precio` decimal(11,2) NOT NULL DEFAULT '0.00',
  `descuento` decimal(11,2) NOT NULL DEFAULT '0.00',
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_articulo_precio_ofertado`),
  UNIQUE KEY `id_articulo` (`id_articulo`,`id_proveedor`,`precio`,`descuento`),
  KEY `id_articulo_2` (`id_articulo`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tr_mantic_articulos_precios_ofertados_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `tc_mantic_articulos` (`id_articulo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulos_precios_ofertados_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_articulos_precios_ofertados_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_cliente_domicilio` */

DROP TABLE IF EXISTS `tr_mantic_cliente_domicilio`;

CREATE TABLE `tr_mantic_cliente_domicilio` (
  `id_cliente_domicilio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `id_domicilio` bigint(11) unsigned NOT NULL,
  `id_tipo_domicilio` bigint(11) unsigned NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_domicilio`),
  UNIQUE KEY `id_cliente` (`id_cliente`,`id_domicilio`,`id_tipo_domicilio`,`id_principal`),
  KEY `id_domicilio` (`id_domicilio`),
  KEY `id_tipo_domicilio` (`id_tipo_domicilio`),
  KEY `id_principal` (`id_principal`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cliente_2` (`id_cliente`),
  CONSTRAINT `tr_mantic_cliente_domicilio_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_cliente_domicilio_ibfk_2` FOREIGN KEY (`id_domicilio`) REFERENCES `tc_mantic_domicilios` (`id_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_cliente_domicilio_ibfk_3` FOREIGN KEY (`id_tipo_domicilio`) REFERENCES `tc_mantic_tipos_domicilios` (`id_tipo_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_cliente_domicilio_ibfk_4` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3516 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_cliente_representante` */

DROP TABLE IF EXISTS `tr_mantic_cliente_representante`;

CREATE TABLE `tr_mantic_cliente_representante` (
  `id_cliente_representante` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `id_representante` bigint(11) unsigned NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_representante`),
  UNIQUE KEY `id_cliente` (`id_cliente`,`id_representante`,`id_principal`),
  KEY `id_cliente_2` (`id_cliente`),
  KEY `id_representante` (`id_representante`),
  KEY `id_principal` (`id_principal`),
  KEY `id_registro` (`id_usuario`),
  CONSTRAINT `tr_mantic_cliente_representante_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_cliente_representante_ibfk_2` FOREIGN KEY (`id_representante`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_cliente_representante_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_cliente_tipo_contacto` */

DROP TABLE IF EXISTS `tr_mantic_cliente_tipo_contacto`;

CREATE TABLE `tr_mantic_cliente_tipo_contacto` (
  `id_cliente_tipo_contacto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `id_tipo_contacto` bigint(11) unsigned NOT NULL,
  `valor` varchar(255) COLLATE latin1_bin NOT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_tipo_contacto`),
  UNIQUE KEY `id_cliente` (`id_cliente`,`id_tipo_contacto`,`valor`),
  KEY `id_tipo_contacto` (`id_tipo_contacto`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cliente_2` (`id_cliente`),
  CONSTRAINT `tr_mantic_cliente_tipo_contacto_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_cliente_tipo_contacto_ibfk_2` FOREIGN KEY (`id_tipo_contacto`) REFERENCES `tc_mantic_tipos_contactos` (`id_tipo_contacto`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_clientes_representantes` */

DROP TABLE IF EXISTS `tr_mantic_clientes_representantes`;

CREATE TABLE `tr_mantic_clientes_representantes` (
  `id_cliente_representante` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(11) unsigned NOT NULL,
  `id_representante` bigint(11) unsigned NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente_representante`),
  UNIQUE KEY `id_cliente` (`id_cliente`,`id_representante`,`id_principal`),
  KEY `id_cliente_2` (`id_cliente`),
  KEY `id_representante` (`id_representante`),
  KEY `id_principal` (`id_principal`),
  KEY `id_registro` (`id_usuario`),
  CONSTRAINT `tr_mantic_clientes_representantes_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tc_mantic_clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_clientes_representantes_ibfk_2` FOREIGN KEY (`id_representante`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_clientes_representantes_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_empaque_unidad_medida` */

DROP TABLE IF EXISTS `tr_mantic_empaque_unidad_medida`;

CREATE TABLE `tr_mantic_empaque_unidad_medida` (
  `id_empaque_unidad_medida` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empaque` bigint(11) unsigned NOT NULL,
  `id_unidad_medida` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empaque_unidad_medida`),
  UNIQUE KEY `id_presentacion` (`id_empaque`,`id_unidad_medida`),
  KEY `id_presentacion_2` (`id_empaque`),
  KEY `id_unidad_medida` (`id_unidad_medida`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tr_mantic_empaque_unidad_medida_ibfk_1` FOREIGN KEY (`id_empaque`) REFERENCES `tc_mantic_empaques` (`id_empaque`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_empaque_unidad_medida_ibfk_2` FOREIGN KEY (`id_unidad_medida`) REFERENCES `tc_mantic_unidades_medidas` (`id_unidad_medida`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_empaque_unidad_medida_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_empresa_domicilio` */

DROP TABLE IF EXISTS `tr_mantic_empresa_domicilio`;

CREATE TABLE `tr_mantic_empresa_domicilio` (
  `id_empresa_domicilio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_domicilio` bigint(11) unsigned NOT NULL,
  `id_tipo_domicilio` bigint(11) NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empresa_domicilio`),
  UNIQUE KEY `id_empresa` (`id_empresa`,`id_domicilio`,`id_tipo_domicilio`,`id_principal`),
  KEY `id_empresa_2` (`id_empresa`),
  KEY `id_domicilio` (`id_domicilio`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_tipo_domicilio` (`id_tipo_domicilio`),
  KEY `id_principal` (`id_principal`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_empresa_personal` */

DROP TABLE IF EXISTS `tr_mantic_empresa_personal`;

CREATE TABLE `tr_mantic_empresa_personal` (
  `id_empresa_persona` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_persona` bigint(11) unsigned NOT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `id_puesto` bigint(11) unsigned NOT NULL,
  `fecha_contratacion` date DEFAULT NULL,
  `nss` varbinary(100) DEFAULT NULL,
  `contrato` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `infonavit` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `factor_infonavit` decimal(11,4) DEFAULT '0.0000',
  `sueldo_semanal` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `sueldo_mensual` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `sueldo_imss` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `diario_imss` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `id_departamento` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_contratista` bigint(11) unsigned DEFAULT NULL,
  `id_activo` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empresa_persona`),
  UNIQUE KEY `id_empresa_uk` (`id_empresa`,`id_persona`,`id_puesto`),
  KEY `id_persona` (`id_persona`),
  KEY `id_puesto` (`id_puesto`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_departamento` (`id_departamento`),
  KEY `id_contratista` (`id_contratista`),
  KEY `id_activo` (`id_activo`),
  CONSTRAINT `tr_mantic_empresa_personal_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_empresa_personal_ibfk_2` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_empresa_personal_ibfk_3` FOREIGN KEY (`id_puesto`) REFERENCES `tc_mantic_puestos` (`id_puesto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_empresa_personal_ibfk_4` FOREIGN KEY (`id_activo`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_empresa_personal_ibfk_5` FOREIGN KEY (`id_departamento`) REFERENCES `tc_keet_departamentos` (`id_departamento`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_empresa_personal_ibfk_6` FOREIGN KEY (`id_contratista`) REFERENCES `tr_mantic_empresa_personal` (`id_empresa_persona`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_empresa_tipo_contacto` */

DROP TABLE IF EXISTS `tr_mantic_empresa_tipo_contacto`;

CREATE TABLE `tr_mantic_empresa_tipo_contacto` (
  `id_empresa_tipo_contacto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(11) unsigned NOT NULL,
  `id_tipo_contacto` bigint(11) unsigned NOT NULL,
  `valor` varchar(255) COLLATE latin1_bin NOT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_empresa_tipo_contacto`),
  UNIQUE KEY `id_empresa` (`id_empresa`,`id_tipo_contacto`),
  KEY `id_tipo_contacto` (`id_tipo_contacto`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa_2` (`id_empresa`),
  CONSTRAINT `tr_mantic_empresa_tipo_contacto_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `tc_mantic_empresas` (`id_empresa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_empresa_tipo_contacto_ibfk_2` FOREIGN KEY (`id_tipo_contacto`) REFERENCES `tc_mantic_tipos_contactos` (`id_tipo_contacto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_empresa_tipo_contacto_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_garantia_medio_pago` */

DROP TABLE IF EXISTS `tr_mantic_garantia_medio_pago`;

CREATE TABLE `tr_mantic_garantia_medio_pago` (
  `id_garantia_medio_pago` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cierre` bigint(11) unsigned DEFAULT NULL,
  `id_garantia` bigint(11) unsigned NOT NULL,
  `id_tipo_medio_pago` bigint(11) unsigned NOT NULL,
  `importe` decimal(11,2) DEFAULT '0.00',
  `id_banco` bigint(11) unsigned DEFAULT NULL,
  `referencia` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_garantia_medio_pago`),
  UNIQUE KEY `id_garantia_uk` (`id_garantia`,`id_tipo_medio_pago`,`importe`,`id_banco`),
  KEY `id_tipo_medio_pago` (`id_tipo_medio_pago`),
  KEY `id_banco` (`id_banco`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_venta` (`id_garantia`),
  KEY `id_cierre` (`id_cierre`),
  CONSTRAINT `tr_mantic_garantia_medio_pago_ibfk_1` FOREIGN KEY (`id_cierre`) REFERENCES `tc_mantic_cierres` (`id_cierre`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_garantia_medio_pago_ibfk_2` FOREIGN KEY (`id_garantia`) REFERENCES `tc_mantic_garantias` (`id_garantia`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_garantia_medio_pago_ibfk_3` FOREIGN KEY (`id_tipo_medio_pago`) REFERENCES `tc_mantic_tipos_medios_pagos` (`id_tipo_medio_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_garantia_medio_pago_ibfk_4` FOREIGN KEY (`id_banco`) REFERENCES `tc_mantic_bancos` (`id_banco`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_garantia_medio_pago_ibfk_5` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_orden_compra_cargo` */

DROP TABLE IF EXISTS `tr_mantic_orden_compra_cargo`;

CREATE TABLE `tr_mantic_orden_compra_cargo` (
  `id_orden_compra_cargo` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_orden_compra` bigint(11) unsigned NOT NULL,
  `id_cargo_compra` bigint(11) unsigned NOT NULL,
  `porcentaje` decimal(11,2) NOT NULL DEFAULT '0.00',
  `importe` decimal(11,2) NOT NULL DEFAULT '0.00',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_orden_compra_cargo`),
  UNIQUE KEY `id_orden_compra` (`id_orden_compra`,`id_cargo_compra`,`porcentaje`,`importe`),
  KEY `id_orden_compra_2` (`id_orden_compra`),
  KEY `id_cargo_compra` (`id_cargo_compra`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tr_mantic_orden_compra_cargo_ibfk_1` FOREIGN KEY (`id_orden_compra`) REFERENCES `tc_mantic_ordenes_compras` (`id_orden_compra`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_orden_compra_cargo_ibfk_2` FOREIGN KEY (`id_cargo_compra`) REFERENCES `tc_mantic_cargos_compras` (`id_cargo_compra`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_orden_compra_cargo_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_persona_domicilio` */

DROP TABLE IF EXISTS `tr_mantic_persona_domicilio`;

CREATE TABLE `tr_mantic_persona_domicilio` (
  `id_persona_domicilio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(11) unsigned NOT NULL,
  `id_domicilio` bigint(11) unsigned NOT NULL,
  `id_tipo_domicilio` bigint(11) unsigned NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL,
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_persona_domicilio`,`id_usuario`),
  UNIQUE KEY `id_persona` (`id_persona`,`id_domicilio`,`id_tipo_domicilio`,`id_principal`),
  KEY `id_domicilio` (`id_domicilio`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_tipo_domicilio` (`id_tipo_domicilio`),
  KEY `id_principal` (`id_principal`),
  KEY `id_persona_2` (`id_persona`),
  CONSTRAINT `tr_mantic_persona_domicilio_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_persona_domicilio_ibfk_2` FOREIGN KEY (`id_domicilio`) REFERENCES `tc_mantic_domicilios` (`id_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_persona_domicilio_ibfk_3` FOREIGN KEY (`id_tipo_domicilio`) REFERENCES `tc_mantic_tipos_domicilios` (`id_tipo_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_persona_domicilio_ibfk_4` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_persona_domicilio_ibfk_5` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_persona_tipo_contacto` */

DROP TABLE IF EXISTS `tr_mantic_persona_tipo_contacto`;

CREATE TABLE `tr_mantic_persona_tipo_contacto` (
  `id_persona_tipo_contacto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_persona` bigint(11) unsigned NOT NULL,
  `id_tipo_contacto` bigint(11) unsigned NOT NULL,
  `valor` varchar(255) COLLATE latin1_bin NOT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_persona_tipo_contacto`),
  UNIQUE KEY `id_persona` (`id_persona`,`id_tipo_contacto`,`valor`),
  KEY `id_tipo_contacto` (`id_tipo_contacto`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_persona_2` (`id_persona`),
  CONSTRAINT `tr_mantic_persona_tipo_contacto_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_persona_tipo_contacto_ibfk_2` FOREIGN KEY (`id_tipo_contacto`) REFERENCES `tc_mantic_tipos_contactos` (`id_tipo_contacto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_persona_tipo_contacto_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_proveedor_agente` */

DROP TABLE IF EXISTS `tr_mantic_proveedor_agente`;

CREATE TABLE `tr_mantic_proveedor_agente` (
  `id_proveedor_agente` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `id_agente` bigint(11) unsigned NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '2',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor_agente`),
  UNIQUE KEY `id_proveedor` (`id_proveedor`,`id_agente`,`id_principal`),
  KEY `id_proveedor_2` (`id_proveedor`),
  KEY `id_agente` (`id_agente`),
  KEY `id_principal` (`id_principal`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tr_mantic_proveedor_agente_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_agente_ibfk_2` FOREIGN KEY (`id_agente`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_agente_ibfk_3` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_proveedor_domicilio` */

DROP TABLE IF EXISTS `tr_mantic_proveedor_domicilio`;

CREATE TABLE `tr_mantic_proveedor_domicilio` (
  `id_proveedor_domicilio` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `id_domicilio` bigint(11) unsigned NOT NULL,
  `id_tipo_domicilio` bigint(11) unsigned NOT NULL,
  `id_principal` bigint(11) unsigned NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor_domicilio`),
  UNIQUE KEY `id_proveedor` (`id_proveedor`,`id_domicilio`,`id_tipo_domicilio`,`id_principal`),
  KEY `id_proveedor_2` (`id_proveedor`),
  KEY `id_domicilio` (`id_domicilio`),
  KEY `id_tipo_domicilio` (`id_tipo_domicilio`),
  KEY `id_principal` (`id_principal`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tr_mantic_proveedor_domicilio_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_domicilio_ibfk_2` FOREIGN KEY (`id_domicilio`) REFERENCES `tc_mantic_domicilios` (`id_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_domicilio_ibfk_3` FOREIGN KEY (`id_tipo_domicilio`) REFERENCES `tc_mantic_tipos_domicilios` (`id_tipo_domicilio`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_domicilio_ibfk_4` FOREIGN KEY (`id_principal`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_proveedor_pago` */

DROP TABLE IF EXISTS `tr_mantic_proveedor_pago`;

CREATE TABLE `tr_mantic_proveedor_pago` (
  `id_proveedor_pago` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `id_tipo_pago` bigint(11) unsigned NOT NULL,
  `clave` varchar(100) COLLATE latin1_bin NOT NULL,
  `descuento` varchar(100) COLLATE latin1_bin NOT NULL DEFAULT '0.00',
  `plazo` bigint(11) unsigned NOT NULL DEFAULT '0',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_vigente` bigint(11) unsigned NOT NULL DEFAULT '1',
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor_pago`),
  UNIQUE KEY `id_proveedor_uk` (`id_proveedor`,`id_tipo_pago`,`descuento`),
  KEY `id_tipo_pago` (`id_tipo_pago`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_vigente` (`id_vigente`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `tr_mantic_proveedor_pago_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_pago_ibfk_2` FOREIGN KEY (`id_tipo_pago`) REFERENCES `tc_mantic_tipos_pagos` (`id_tipo_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_pago_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_pago_ibfk_4` FOREIGN KEY (`id_vigente`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_proveedor_persona` */

DROP TABLE IF EXISTS `tr_mantic_proveedor_persona`;

CREATE TABLE `tr_mantic_proveedor_persona` (
  `id_proveedor_persona` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `id_persona` bigint(11) unsigned NOT NULL,
  `id_responsable` bigint(11) unsigned NOT NULL DEFAULT '2',
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor_persona`),
  UNIQUE KEY `id_proveedor` (`id_proveedor`,`id_persona`,`id_responsable`),
  KEY `id_proveedor_2` (`id_proveedor`),
  KEY `id_persona` (`id_persona`),
  KEY `id_responsable` (`id_responsable`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tr_mantic_proveedor_persona_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_persona_ibfk_2` FOREIGN KEY (`id_persona`) REFERENCES `tc_mantic_personas` (`id_persona`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_persona_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_persona_ibfk_4` FOREIGN KEY (`id_responsable`) REFERENCES `tc_janal_booleanos` (`id_booleano`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_proveedor_tipo_contacto` */

DROP TABLE IF EXISTS `tr_mantic_proveedor_tipo_contacto`;

CREATE TABLE `tr_mantic_proveedor_tipo_contacto` (
  `id_proveedor_tipo_contacto` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_proveedor` bigint(11) unsigned NOT NULL,
  `id_tipo_contacto` bigint(11) unsigned NOT NULL,
  `valor` varchar(255) COLLATE latin1_bin NOT NULL,
  `orden` bigint(11) NOT NULL DEFAULT '1',
  `observaciones` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned DEFAULT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor_tipo_contacto`),
  UNIQUE KEY `id_proveedor` (`id_proveedor`,`id_tipo_contacto`,`valor`),
  KEY `id_proveedor_2` (`id_proveedor`),
  KEY `id_tipo_contacto` (`id_tipo_contacto`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `tr_mantic_proveedor_tipo_contacto_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tc_mantic_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_tipo_contacto_ibfk_2` FOREIGN KEY (`id_tipo_contacto`) REFERENCES `tc_mantic_tipos_contactos` (`id_tipo_contacto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_proveedor_tipo_contacto_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `tr_mantic_venta_medio_pago` */

DROP TABLE IF EXISTS `tr_mantic_venta_medio_pago`;

CREATE TABLE `tr_mantic_venta_medio_pago` (
  `id_venta_medio_pago` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_cierre` bigint(11) unsigned DEFAULT NULL,
  `id_venta` bigint(11) unsigned NOT NULL,
  `id_tipo_medio_pago` bigint(11) unsigned NOT NULL,
  `importe` decimal(11,2) DEFAULT '0.00',
  `total` decimal(11,2) unsigned NOT NULL DEFAULT '0.00',
  `id_banco` bigint(11) unsigned DEFAULT NULL,
  `referencia` varchar(100) COLLATE latin1_bin DEFAULT NULL,
  `observaciones` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `id_usuario` bigint(11) unsigned NOT NULL,
  `registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_venta_medio_pago`),
  UNIQUE KEY `id_venta_uk` (`id_venta`,`id_tipo_medio_pago`,`importe`,`id_banco`),
  KEY `id_tipo_medio_pago` (`id_tipo_medio_pago`),
  KEY `id_banco` (`id_banco`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_venta` (`id_venta`),
  KEY `id_cierre` (`id_cierre`),
  CONSTRAINT `tr_mantic_venta_medio_pago_ibfk_1` FOREIGN KEY (`id_venta`) REFERENCES `tc_mantic_ventas` (`id_venta`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_venta_medio_pago_ibfk_2` FOREIGN KEY (`id_tipo_medio_pago`) REFERENCES `tc_mantic_tipos_medios_pagos` (`id_tipo_medio_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_venta_medio_pago_ibfk_3` FOREIGN KEY (`id_banco`) REFERENCES `tc_mantic_bancos` (`id_banco`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_venta_medio_pago_ibfk_4` FOREIGN KEY (`id_usuario`) REFERENCES `tc_janal_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tr_mantic_venta_medio_pago_ibfk_5` FOREIGN KEY (`id_cierre`) REFERENCES `tc_mantic_cierres` (`id_cierre`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
